#!/usr/bin/env python3
"""
Facebook Visual Generator Module (Photoshop-Grade & Anti-AI-Slop)
Generates high-contrast, thumb-stopping 1:1 square & 4:5 portrait visuals for Facebook posts:
- Primary engine: AGY generate_image (Isometric 3D, Vibrant Swiss, 35mm Studio Photo, Risograph, Whiteboard, TUI).
- Curated safety engine: Rotates from authentic AGY-generated Photoshop-grade library in ~/cdn.
- ZERO Pillow flowchart diagrams. ZERO generic neon boxes. Pure professional digital design.
"""

import os
import sys
import json
import shutil
import hashlib
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Any

DEFAULT_OUTPUT_DIR = Path.home() / ".config" / "facebook" / "visuals"
CDN_DIR = Path.home() / "cdn"
VISUAL_HISTORY_FILE = Path.home() / ".config" / "facebook" / "visual_history.json"

# The 6 Golden Standard thumb-stopping design styles for Vasil Tech Lead
DESIGN_STYLES = [
    {
        "style": "isometric_3d",
        "name": "Isometric 3D Modular Architecture",
        "keywords": ["isometric", "blueprint", "singlepass", "arch"],
        "prompt_template": (
            "Modern 3D isometric modular architecture visualization on deep matte obsidian graphite background. "
            "Linear app and Figma design aesthetic with tilt-shift depth of field and soft ambient occlusion. "
            "Clean geometric compute nodes, glowing Electric Lime (#CCFF00) and International Klein Blue (#002FA7) data conduits, "
            "high-density silicon substrate, clean volumetric studio lighting for '{topic}'. "
            "Top-tier Photoshop digital art, award-winning 3D render. "
            "NO humanoid robots, NO generic neon slop, NO blurry pseudo-text, NO stock vector art."
        )
    },
    {
        "style": "vibrant_swiss",
        "name": "Vibrant Swiss Graphic Poster",
        "keywords": ["swiss", "poster"],
        "prompt_template": (
            "Vibrant Swiss Graphic Design poster, International Typographic Style. "
            "High-contrast color blocking with bold Safety Orange (#FF5000), deep cobalt blue, and crisp white on rich charcoal. "
            "Rigid asymmetric grid alignment, dynamic geometric diagonal dividers, bold graphic tension for '{topic}'. "
            "Minimalist modernist exhibition poster, clean museum-grade graphic design. "
            "NO blurry artifacts, NO tiny unreadable text, clean sharp vector geometry."
        )
    },
    {
        "style": "studio_photo",
        "name": "Authentic 35mm Studio Photography",
        "keywords": ["photo", "workspace", "macro", "hardware"],
        "prompt_template": (
            "Authentic 35mm studio photography of precision engineering hardware. "
            "Leica M11 50mm f/1.4 aesthetic with shallow natural depth of field and cinematic bokeh. "
            "Brushed anodized aluminum chassis, braided copper power busbars, clean server rack backplane with warm tungsten "
            "and subtle cyan LED accents, tactile physical textures, editorial tech magazine cover photo for '{topic}'. "
            "Photorealistic, crisp optical reflections, authentic physical hardware. "
            "NO CGI plasticky look, NO fantasy sci-fi slop, NO people, NO faces."
        )
    },
    {
        "style": "risograph",
        "name": "Neo-Brutalist Risograph Print",
        "keywords": ["risograph", "acid"],
        "prompt_template": (
            "Neo-brutalist two-tone risograph print on textured warm cream paper. "
            "Vivid fluorescent orange (#FF5500) and deep Prussian blue ink overlay with visible halftone dot screen pattern. "
            "Raw editorial tech illustration, bold industrial symbolism, misregistered ink bleed aesthetic for '{topic}'. "
            "High contrast tactile risograph art print, underground zine aesthetic. "
            "NO 3D gradients, NO generic corporate illustration, NO stock characters."
        )
    },
    {
        "style": "whiteboard",
        "name": "Technical Engineering Whiteboard",
        "keywords": ["whiteboard", "bench"],
        "prompt_template": (
            "Authentic technical engineering whiteboard diagram drawn with crisp dry-erase markers. "
            "Glossy white office whiteboard with subtle marker textures and realistic room reflections. "
            "Technical architecture flow with chisel-tip dark blue and safety orange markers, node connections, "
            "hand-drawn underlines and clean technical callouts for '{topic}'. "
            "Professional engineering war-room aesthetic, crisp high-contrast layout. "
            "NO tiny unreadable scribbles, NO messy smudges, clean readable architecture."
        )
    },
    {
        "style": "tui_terminal",
        "name": "Next-Gen TUI Terminal Interface",
        "keywords": ["tui", "terminal", "dark_ui"],
        "prompt_template": (
            "Hyper-modern TUI (Terminal User Interface) software dashboard on dark OLED background. "
            "Tokyo Night color palette with glowing cyan, emerald, and amber metrics telemetry. "
            "Crisp monospace layout, box-drawing unicode dividers, data stream visualization for '{topic}'. "
            "Futuristic developer terminal aesthetic, subtle CRT bloom, clean engineering interface. "
            "NO messy artifacts, sharp high-DPI terminal display."
        )
    }
]


def _find_agy() -> Optional[str]:
    """Find agy CLI binary path across common system and user paths."""
    for p in ["agy", "/home/ubuntu/.local/bin/agy", "/usr/local/bin/agy", str(Path.home() / ".local" / "bin" / "agy")]:
        found = shutil.which(p)
        if found:
            return found
        if os.path.isabs(p) and os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def _load_visual_history() -> List[str]:
    """Load list of recently used image filenames to prevent repetitive visuals."""
    if VISUAL_HISTORY_FILE.exists():
        try:
            with open(VISUAL_HISTORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("used_images", [])
        except Exception:
            return []
    return []


def _record_visual_history(image_name: str) -> None:
    """Record an image filename in history, keeping the last 40 entries."""
    try:
        VISUAL_HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        hist = _load_visual_history()
        hist.append(image_name)
        if len(hist) > 40:
            hist = hist[-40:]
        with open(VISUAL_HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump({"used_images": hist}, f, indent=2)
    except Exception:
        pass


def build_photoshop_prompt(topic: str, theme: str = "", slot_name: str = "") -> str:
    """
    Build a top-tier Photoshop-grade prompt adhering to the 6 Golden Standard styles:
    Rotates dynamically across styles based on topic hash to ensure visual diversity.
    """
    s = (slot_name or "").lower().strip()
    topic_clean = topic.strip().replace('"', "'")

    # Select style based on slot category or topic hash
    if "opensource" in s or "devtool" in s:
        target_styles = [0, 4, 1]  # Isometric 3D, Whiteboard, Swiss
    elif "ai" in s:
        target_styles = [1, 5, 0, 3]  # Swiss, TUI Terminal, Isometric, Risograph
    elif "holivar" in s or "debate" in s:
        target_styles = [3, 1, 5]  # Risograph, Swiss, TUI
    elif "career" in s or "philosophy" in s:
        target_styles = [2, 1]  # 35mm Studio Photo, Swiss
    else:
        target_styles = list(range(len(DESIGN_STYLES)))

    # Deterministic style index based on topic hash
    h_idx = abs(hash(topic_clean)) % len(target_styles)
    selected_style = DESIGN_STYLES[target_styles[h_idx]]

    return selected_style["prompt_template"].format(topic=topic_clean)


def select_curated_photoshop_visual(
    slot_name: str = "",
    topic: str = "",
    output_path: Optional[Path] = None
) -> Path:
    """
    Select an authentic, pre-generated Photoshop-grade AGY artwork from ~/cdn
    matching the post theme, ensuring zero repetitive posts and 100% elimination of Pillow boxes.
    """
    if not output_path:
        DEFAULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        import uuid
        output_path = DEFAULT_OUTPUT_DIR / f"fb_curated_{uuid.uuid4().hex[:8]}.jpg"

    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Search for CDN images
    available_images = []
    if CDN_DIR.exists():
        available_images = [f for f in CDN_DIR.glob("*.jpg") if f.is_file() and f.stat().st_size > 15000]

    # Fallback to local config visuals directory if CDN not found
    if not available_images:
        local_cdn = Path.home() / ".config" / "facebook" / "visuals"
        available_images = [f for f in local_cdn.glob("*.jpg") if f.is_file() and f.stat().st_size > 15000]

    if not available_images:
        raise RuntimeError("No curated Photoshop-grade visuals found in ~/cdn or local storage.")

    # Match preferred keywords by slot
    s = (slot_name or "").lower()
    if "opensource" in s or "devtool" in s:
        pref_keywords = ["isometric", "blueprint", "whiteboard", "matrix", "singlepass"]
    elif "ai" in s:
        pref_keywords = ["swiss", "tui", "terminal", "risograph", "bench"]
    elif "holivar" in s or "debate" in s:
        pref_keywords = ["risograph", "swiss", "acid", "terminal"]
    elif "career" in s or "philosophy" in s:
        pref_keywords = ["photo", "workspace", "swiss"]
    else:
        pref_keywords = ["isometric", "swiss", "whiteboard", "photo"]

    matched = [img for img in available_images if any(k in img.name.lower() for k in pref_keywords)]
    candidates = matched if matched else available_images

    # Filter out recently used images to maximize visual variety
    history = _load_visual_history()
    fresh_candidates = [img for img in candidates if img.name not in history]
    pool = fresh_candidates if fresh_candidates else candidates

    # Select stable image using topic hash
    selected = pool[abs(hash(topic + slot_name)) % len(pool)]
    shutil.copyfile(str(selected), str(output_path))
    _record_visual_history(selected.name)

    print(f"✓ Обрано перевірений дизайн-візуал з арт-галереї: {selected.name} -> {output_path}")
    return output_path


def generate_post_image(
    topic: str,
    theme: str = "",
    slot_name: str = "",
    points: Optional[List[str]] = None,
    output_path: Optional[Path] = None
) -> Path:
    """
    Generate or provide a Photoshop-grade, thumb-stopping visual for a Facebook post:
    1. Attempts live AI image generation via `agy` CLI using the 6 Golden Standard design prompts.
    2. If agy hits quota limits (HTTP 429) or is unavailable, seamlessly uses the authentic
       AGY Photoshop-grade visual library in ~/cdn.
    3. ZERO Pillow flowchart diagrams. Guaranteed 100% professional graphic design.
    """
    if not output_path:
        DEFAULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        import uuid
        output_path = DEFAULT_OUTPUT_DIR / f"fb_post_{uuid.uuid4().hex[:8]}.jpg"

    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    enable_ai = os.environ.get("FB_ENABLE_AI_IMAGE", "1").strip().lower() not in ("0", "false", "no")
    if enable_ai:
        try:
            import sys
            if "/home/ubuntu/.local/bin" not in sys.path:
                sys.path.append("/home/ubuntu/.local/bin")
            import visual_engine
            print(f"🤖 Запуск генерації Photoshop-grade зображення через NVIDIA NIM + FLUX.1...")
            out_file, _ = visual_engine.generate_visual(topic=topic, output_file=output_path, push_cdn=False)
            if out_file.exists() and out_file.stat().st_size > 15000:
                print(f"✓ AI-зображення успішно згенеровано через NVIDIA NIM + FLUX.1: {out_file} ({out_file.stat().st_size:,} bytes)")
                return out_file
        except Exception as e:
            print(f"ℹ️ Live-генератор повідомив: {e}. Спробуємо альтернативні канали.")

    agy_path = _find_agy() if enable_ai else None

    if agy_path:
        import uuid
        art_prompt = build_photoshop_prompt(topic, theme, slot_name)
        img_name = f"fb_art_{uuid.uuid4().hex[:6]}"
        agy_prompt = (
            f"Use the generate_image tool to generate an image. "
            f"Prompt: {art_prompt}. "
            f"AspectRatio: 1:1. "
            f"ImageName: {img_name}. "
            f"Do not read or execute any local python scripts. Only invoke generate_image tool. "
            f"Once generated, find the saved image file and copy it to {output_path}. "
            f"Then print DONE."
        )
        try:
            print(f"🤖 Запуск генерації Photoshop-grade зображення через agy ({agy_path})...")
            proc = subprocess.run(
                [str(agy_path), "--dangerously-skip-permissions", "-p", agy_prompt],
                capture_output=True,
                timeout=35,
                text=True
            )
            if output_path.exists() and os.path.getsize(output_path) > 15000:
                print(f"✓ AI-зображення успішно згенеровано через agy: {output_path}")
                return output_path
            else:
                print(f"ℹ️ agy тимчасово призупинив генерацію (квота або ліміт). Підключаємо дизайн-галерею.")
        except Exception as e:
            print(f"ℹ️ agy недоступний ({e}). Підключаємо дизайн-галерею.")

    # Seamless fallback to authentic Photoshop-grade visual from curated gallery
    return select_curated_photoshop_visual(
        slot_name=slot_name,
        topic=topic,
        output_path=output_path
    )


# Backward compatibility alias - redirect any legacy callers to curated visual selector
def generate_card(
    topic: str,
    theme: str = "",
    slot_name: str = "",
    points: Optional[List[str]] = None,
    output_path: Optional[Path] = None
) -> Path:
    """Legacy alias: redirects directly to Photoshop-grade visual selection."""
    return select_curated_photoshop_visual(
        slot_name=slot_name,
        topic=topic,
        output_path=output_path
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate Photoshop-grade visuals for Facebook posts")
    parser.add_argument("--topic", required=True, help="Post topic")
    parser.add_argument("--theme", default="", help="Theme or slot name")
    parser.add_argument("--slot", default="", help="Slot slug name (e.g. opensource, ai_news, architecture)")
    parser.add_argument("--output", default="", help="Output image file path")
    args = parser.parse_args()

    out_p = Path(args.output) if args.output else None
    result = generate_post_image(
        topic=args.topic,
        theme=args.theme,
        slot_name=args.slot,
        output_path=out_p
    )
    print(f"✓ Visual ready: {result} ({os.path.getsize(result):,} bytes)")
