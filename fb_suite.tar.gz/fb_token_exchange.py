#!/usr/bin/env python3
"""
Facebook Permanent Token Exchange Utility
Exchanges a fresh short-lived User Token for a 60-day Long-Lived User Token,
then retrieves a Never-Expiring (Permanent) Page Access Token for «Василь Tech Lead»,
and automatically deploys it to ~/.config/facebook/.env locally and on VPS 2.
"""

import os
import sys
import json
import urllib.request
import urllib.parse
import urllib.error
import subprocess
from pathlib import Path

ENV_FILE = Path.home() / ".config" / "facebook" / ".env"

def load_env():
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.strip().strip("'\"")
                    if k not in os.environ:
                        os.environ[k] = v

load_env()

APP_ID = os.environ.get("FB_APP_ID", "947245831153691").strip()
APP_SECRET = os.environ.get("FB_APP_SECRET", "").strip()
PAGE_ID = os.environ.get("FB_PAGE_ID", "1299711009894993").strip()


def exchange_token(short_lived_user_token: str):
    if not APP_ID or not APP_SECRET:
        print("❌ Помилка: FB_APP_ID або FB_APP_SECRET не знайдено в конфізі.")
        sys.exit(1)

    print("=" * 65)
    print("🔄 Генерація вічного (Permanent) токена для сторінки Facebook...")
    print(f"📱 App ID: {APP_ID}")
    print(f"📄 Target Page ID: {PAGE_ID}")
    print("=" * 65)

    # 1. Exchange short-lived user token for 60-day long-lived user token
    print("\n[1/3] 📡 Обмін короткоживучого токена на 60-денний User Token...")
    params = urllib.parse.urlencode({
        "grant_type": "fb_exchange_token",
        "client_id": APP_ID,
        "client_secret": APP_SECRET,
        "fb_exchange_token": short_lived_user_token.strip(),
    })
    url = f"https://graph.facebook.com/v19.0/oauth/access_token?{params}"

    try:
        with urllib.request.urlopen(url, timeout=20) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        print(f"❌ Помилка обміну токена (HTTP {e.code}): {e.read().decode()}")
        sys.exit(1)

    long_lived_user_token = data.get("access_token")
    expires_in = data.get("expires_in", 0)
    print(f"✓ Отримано довговічний User Token (термін дії: {expires_in // 86400} днів)")

    # 2. Get Page Access Token using the long-lived user token
    print("\n[2/3] 📄 Отримання безстрокового токена сторінки (Page Access Token)...")
    url_accounts = f"https://graph.facebook.com/v19.0/me/accounts?access_token={long_lived_user_token}"

    try:
        with urllib.request.urlopen(url_accounts, timeout=20) as resp:
            accounts_data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        print(f"❌ Помилка отримання акаунтів (HTTP {e.code}): {e.read().decode()}")
        sys.exit(1)

    page_token = None
    page_name = None
    for item in accounts_data.get("data", []):
        if str(item.get("id")) == str(PAGE_ID):
            page_token = item.get("access_token")
            page_name = item.get("name")
            break

    if not page_token:
        print(f"❌ Помилка: Сторінку з ID {PAGE_ID} не знайдено серед доступних сторінок користувача.")
        print("Доступні сторінки:")
        for item in accounts_data.get("data", []):
            print(f" - {item.get('name')} (ID: {item.get('id')})")
        sys.exit(1)

    print(f"✓ Отримано токен для сторінки «{page_name}» (ID: {PAGE_ID})")

    # 3. Verify Token Expiration with debug_token
    print("\n[3/3] 🔍 Перевірка терміну дії в Meta Debugger...")
    app_token = f"{APP_ID}|{APP_SECRET}"
    url_debug = f"https://graph.facebook.com/v19.0/debug_token?input_token={page_token}&access_token={app_token}"

    try:
        with urllib.request.urlopen(url_debug, timeout=20) as resp:
            debug_info = json.loads(resp.read().decode()).get("data", {})
            expires_at = debug_info.get("expires_at", 0)
            if expires_at == 0:
                print("🎉 ПІДТВЕРДЖЕНО: Токен сторінки БЕЗСТРОКОВИЙ (Never Expires / Термін дії необмежений)!")
            else:
                print(f"ℹ️ Токен сторінки діє до timestamp: {expires_at}")
    except Exception as e:
        print(f"⚠️ Не вдалося виконати debug_token ({e}), продовжуємо...")

    # 4. Save locally and deploy to VPS 2
    update_env_and_deploy(page_token, long_lived_user_token)


def update_env_and_deploy(page_token: str, user_token: str):
    print("\n💾 Збереження токенів у конфігураційні файли...")

    bot_token = os.environ.get("FB_TELEGRAM_BOT_TOKEN", "8647517877:AAFX2O3j3w3nsgHoR1siqiukz42GoTvOb_I").strip()
    admin_id = os.environ.get("FB_ADMIN_CHAT_ID", "792301169").strip()

    env_content = f"""FB_PAGE_ID="1299711009894993"
FB_PAGE_NAME="Василь Tech Lead"
FB_APP_ID="{APP_ID}"
FB_APP_SECRET="{APP_SECRET}"
FB_PAGE_ACCESS_TOKEN="{page_token}"
FB_USER_ACCESS_TOKEN="{user_token}"
FB_TELEGRAM_BOT_TOKEN="{bot_token}"
FB_ADMIN_CHAT_ID="{admin_id}"
"""

    # Local write
    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.write(env_content)
    os.chmod(ENV_FILE, 0o600)
    print("✓ Оновлено локальний файл ~/.config/facebook/.env (chmod 600)")

    # VPS 2 deploy
    print("\n🚀 Синхронізація на VPS 2 (158.180.29.226)...")
    try:
        subprocess.run(
            ["scp", "-o", "ConnectTimeout=5", "-o", "StrictHostKeyChecking=no", str(ENV_FILE), "ubuntu@158.180.29.226:/home/ubuntu/.config/facebook/.env"],
            check=True,
            capture_output=True
        )
        subprocess.run(
            ["ssh", "-o", "ConnectTimeout=5", "-o", "StrictHostKeyChecking=no", "ubuntu@158.180.29.226", "chmod 600 ~/.config/facebook/.env && sudo systemctl restart fb-bot.service"],
            check=True,
            capture_output=True
        )
        print("✓ VPS 2 оновлено та перезапущено службу fb-bot.service!")
        print("=" * 65)
        print("🎉 ВСЕ ГОТОВО! Бот та автопостинг повністю активні з безстроковим токеном!")
        print("=" * 65)
    except Exception as e:
        print(f"⚠️ Помилка синхронізації з VPS 2: {e}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Використання: python3 fb_token_exchange.py <новий_user_token_з_graph_api_explorer>")
        sys.exit(1)

    exchange_token(sys.argv[1])
