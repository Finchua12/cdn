#!/usr/bin/env python3
"""
Common utilities for VasylAI Facebook Automation Suite.
Handles environment loading, credential resolution, and secret sanitization.
"""

import html
import os
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path
from typing import Optional, Union, Iterable, Dict, Any, Tuple

ENV_FILE = Path.home() / ".config" / "facebook" / ".env"


def load_env(env_path: Optional[Union[str, Path]] = None) -> None:
    """Load environment variables from ~/.config/facebook/.env or specified path."""
    target_path = Path(env_path) if env_path else ENV_FILE
    if target_path.exists():
        with open(target_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.strip().strip("'\"")
                    if k not in os.environ:
                        os.environ[k] = v


# Auto-load environment on module import
load_env()


def mask_token(token: Optional[str]) -> str:
    """
    Mask sensitive token string (e.g. EAANdg9t...cdef).
    Returns '***' for short or empty strings.
    """
    if not token or len(token) < 13:
        return "***"
    return f"{token[:8]}...{token[-4:]}"


def sanitize_text(
    text: Any,
    token: Optional[Union[str, Iterable[str]]] = None,
    tokens: Optional[Iterable[str]] = None
) -> str:
    """
    Sanitize secrets from text, URL, query parameters, or error messages.
    Supports single token or collection of tokens passed via `token` or `tokens`.
    Automatically checks known sensitive environment variables.
    """
    if text is None:
        return ""
    if not isinstance(text, str):
        text = str(text)

    tok_list = []

    if token:
        if isinstance(token, str):
            tok_list.append(token)
        else:
            tok_list.extend(token)

    if tokens:
        if isinstance(tokens, str):
            tok_list.append(tokens)
        else:
            tok_list.extend(tokens)

    for env_key in (
        "FB_PAGE_ACCESS_TOKEN",
        "FB_USER_ACCESS_TOKEN",
        "FB_APP_SECRET",
        "TELEGRAM_BOT_TOKEN",
        "BOT_TOKEN"
    ):
        val = os.environ.get(env_key)
        if val and val not in tok_list:
            tok_list.append(val)

    # Sort tokens by length descending so longer tokens are masked first
    valid_tokens = sorted(
        [t for t in set(tok_list) if t and isinstance(t, str) and len(t) >= 6],
        key=len,
        reverse=True
    )

    for tok in valid_tokens:
        text = text.replace(tok, mask_token(tok))

    # Redact access_token= query parameters in URLs
    def redact_query_param(match):
        val = match.group(1)
        if "..." in val or val == "[REDACTED]":
            return match.group(0)
        return f"access_token={mask_token(val)}"

    text = re.sub(r'access_token=([^&\s"\'\\>]+)', redact_query_param, text)

    # Redact Authorization header tokens (e.g. OAuth <token> or Bearer <token>)
    def redact_auth_header(match):
        scheme = match.group(1)
        val = match.group(2)
        if "..." in val:
            return match.group(0)
        return f"{scheme} {mask_token(val)}"

    text = re.sub(r'(OAuth|Bearer)\s+([A-Za-z0-9_\-\.]+)', redact_auth_header, text, flags=re.IGNORECASE)

    # Redact Telegram bot token in URLs: api.telegram.org/bot<token>/
    def redact_tg_url(match):
        val = match.group(1)
        if "..." in val:
            return match.group(0)
        return f"/bot{mask_token(val)}/"

    text = re.sub(r'/bot([0-9]+:[A-Za-z0-9_-]+)/', redact_tg_url, text)

    return text


def find_url(text: Optional[str]) -> Optional[str]:
    """Find the first HTTP/HTTPS URL in text."""
    if not text or not isinstance(text, str):
        return None
    match = re.search(r'https?://[^\s<>"]+', text)
    if not match:
        return None
    url = match.group(0)
    # Strip trailing punctuation if accidentally captured
    while url and url[-1] in ".,;:!?)]}":
        url = url[:-1]
    return url


def clean_web_title(raw_title: str) -> str:
    """Clean HTML entities, whitespace, and branding suffixes from title."""
    if not raw_title:
        return ""
    title = html.unescape(raw_title).strip()
    # Strip site suffixes like " | DOU", " - dev.ua", " | AIN.UA", " - YouTube", etc.
    title = re.sub(r'\s*(\||—|-)\s*(DOU|dev\.ua|AIN\.UA|YouTube|Medium|GitHub|Хабр).*$', '', title, flags=re.IGNORECASE).strip()
    return title


def fetch_url_metadata(url: str, timeout: int = 10) -> Dict[str, str]:
    """
    Fetch webpage HTML and extract title and description from og tags or fallback meta.
    Returns dict: {"url": url, "title": str, "description": str}.
    Never raises exceptions on network/parsing failure.
    """
    res = {"url": url, "title": "", "description": ""}
    if not url:
        return res

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content_type = resp.headers.get("Content-Type", "")
            charset = "utf-8"
            if "charset=" in content_type.lower():
                try:
                    charset = content_type.lower().split("charset=")[-1].split(";")[0].strip()
                except Exception:
                    charset = "utf-8"
            raw_bytes = resp.read(250000)
            html_text = raw_bytes.decode(charset, errors="replace")

        # 1. Title: try og:title first, then <title>
        og_title_m = (
            re.search(r'<meta\s+[^>]*property=["\']og:title["\'][^>]*content=["\']([^"\']*)["\']', html_text, re.IGNORECASE)
            or re.search(r'<meta\s+[^>]*content=["\']([^"\']*)["\'][^>]*property=["\']og:title["\']', html_text, re.IGNORECASE)
        )
        if og_title_m and og_title_m.group(1).strip():
            res["title"] = clean_web_title(og_title_m.group(1))
        else:
            title_m = re.search(r'<title[^>]*>(.*?)</title>', html_text, re.IGNORECASE | re.DOTALL)
            if title_m and title_m.group(1).strip():
                res["title"] = clean_web_title(title_m.group(1))

        # 2. Description: try og:description first, then meta name="description"
        og_desc_m = (
            re.search(r'<meta\s+[^>]*property=["\']og:description["\'][^>]*content=["\']([^"\']*)["\']', html_text, re.IGNORECASE)
            or re.search(r'<meta\s+[^>]*content=["\']([^"\']*)["\'][^>]*property=["\']og:description["\']', html_text, re.IGNORECASE)
            or re.search(r'<meta\s+[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\']', html_text, re.IGNORECASE)
            or re.search(r'<meta\s+[^>]*content=["\']([^"\']*)["\'][^>]*name=["\']description["\']', html_text, re.IGNORECASE)
        )
        if og_desc_m and og_desc_m.group(1).strip():
            raw_desc = og_desc_m.group(1).strip()
            res["description"] = html.unescape(raw_desc).strip()

    except Exception as e:
        # Return partial or empty without breaking caller
        pass

    return res


def get_agy_path() -> Optional[str]:
    """Find absolute path to Antigravity CLI executable."""
    agy_candidates = [
        shutil.which("agy"),
        "/usr/local/bin/agy",
        "/home/ubuntu/.local/bin/agy",
        str(Path.home() / ".local" / "bin" / "agy")
    ]
    for cand in agy_candidates:
        if cand and os.path.exists(cand) and os.access(cand, os.X_OK):
            return cand
    return None


def _clean_ai_output(text: str) -> str:
    """Strip code fences, outer quotes, and system CLI artifacts."""
    if not text:
        return ""
    t = text.strip()
    t = re.sub(r'^```[a-zA-Z]*\n([\s\S]*?)\n```$', r'\1', t).strip()
    if (t.startswith('"') and t.endswith('"')) or (t.startswith("'") and t.endswith("'")):
        t = t[1:-1].strip()
    if (t.startswith('«') and t.endswith('»')) or (t.startswith('“') and t.endswith('”')):
        t = t[1:-1].strip()
    filtered = [
        line for line in t.split('\n')
        if not line.startswith('root agent idle')
        and not line.startswith('Waiting for')
        and not line.startswith('Loaded skill')
    ]
    return '\n'.join(filtered).strip()


def _fallback_edit_title(
    raw_title: str,
    raw_desc: Optional[str] = None,
    user_note: Optional[str] = None
) -> str:
    """
    Heuristic rule-based title editor when AI is unavailable.
    Cleans branding, adapts English patterns, and formats clean Ukrainian Tech Lead title.
    """
    clean = clean_web_title(raw_title)
    if not clean:
        if user_note and len(user_note.strip()) >= 5:
            clean = user_note.strip().split("\n")[0][:80]
        else:
            return "Архітектурний інсайт від Василя Tech Lead"

    clean = re.sub(r'^(?:tutorial|guide|walkthrough|overview|deep dive)[:\s\-]+', '', clean, flags=re.IGNORECASE).strip()
    clean = re.sub(r'^(?:відео|стаття|розбір|огляд)[:\s\-]+', '', clean, flags=re.IGNORECASE).strip()

    m_how = re.match(r'^(?:how\s+to|how\s+do\s+you)\s+(.*)', clean, re.IGNORECASE)
    if m_how:
        return f"Як правильно {m_how.group(1).strip()}: розбір від Tech Lead"[:90]

    m_why_we = re.match(r'^(?:why\s+we|why\s+i)\s+(.*)', clean, re.IGNORECASE)
    if m_why_we:
        return f"Чому ми {m_why_we.group(1).strip()}: досвід на проді"[:90]

    m_why = re.match(r'^(?:why\s+you\s+should|why)\s+(.*)', clean, re.IGNORECASE)
    if m_why:
        return f"Чому {m_why.group(1).strip()}: досвід на проді"[:90]

    m_vs = re.match(r'^(.*?)\s+(?:vs\.?|versus)\s+(.*)', clean, re.IGNORECASE)
    if m_vs:
        return f"{m_vs.group(1).strip()} чи {m_vs.group(2).strip()}: що обрати"[:90]

    m_dd = re.match(r'^(?:understanding|deep\s+dive\s+into)\s+(.*)', clean, re.IGNORECASE)
    if m_dd:
        return f"Глибокий розбір {m_dd.group(1).strip()}: під капотом"[:90]

    clean = clean.strip().rstrip(".,;:-")
    return clean[:90] if clean else "Архітектурний інсайт від Василя Tech Lead"


def edit_reel_title(
    raw_title: str,
    url: Optional[str] = None,
    raw_description: Optional[str] = None,
    user_note: Optional[str] = None,
    timeout: int = 40
) -> str:
    """
    Intelligently edit and adapt Reel title using Antigravity AI ('agy').
    Transforms raw webpage/video titles into high-converting, professional Ukrainian Tech Lead titles.
    Falls back to heuristic rules if AI is unavailable.
    """
    if os.environ.get("FB_DISABLE_AI") == "1":
        return _fallback_edit_title(raw_title, raw_description, user_note)

    agy_path = get_agy_path()
    if agy_path:
        clean_raw = clean_web_title(raw_title)
        prompt = (
            "Ти досвідчений український інженер-практик та Tech Lead Василь (@vasylai_official).\n"
            "Твоє завдання: відредагувати та перетворити назву статті/відео за посиланням на коротку, чіпку та професійну назву для Facebook Reels українською мовою.\n\n"
            f"Вхідна назва: {clean_raw or 'Не вказано'}\n"
        )
        if raw_description:
            prompt += f"Контекст статті: {raw_description[:300]}\n"
        if user_note:
            prompt += f"Нотатка автора: {user_note[:200]}\n"
        if url:
            prompt += f"Посилання: {url}\n"

        prompt += (
            "\nСУВОРІ ПРАВИЛА:\n"
            "1. Мова: виключно українська.\n"
            "2. Тон: практичний, експертний Tech Lead (інтрига, факап на проді чи архітектурний інсайт без дешевого клікбейту).\n"
            "3. Довжина: від 30 до 75 символів (ідеально для Facebook Reels).\n"
            "4. Якщо вхідна назва англійською — обов'язково переклади та адаптуй технічний зміст українською.\n"
            "5. Виведи ВИКЛЮЧНО саму фінальну назву. Без лапок, без 'Назва:', без коментарів."
        )

        try:
            res = subprocess.run(
                [agy_path, "--dangerously-skip-permissions", "-p", prompt],
                capture_output=True,
                text=True,
                timeout=timeout
            )
            if res.returncode == 0 and res.stdout:
                cleaned = _clean_ai_output(res.stdout)
                cleaned = re.sub(r'^(?:назва|заголовок|title)[:\s\-]+', '', cleaned, flags=re.IGNORECASE).strip()
                first_line = cleaned.split('\n')[0].strip()
                if len(first_line) >= 6:
                    return first_line[:95]
        except Exception:
            pass

    return _fallback_edit_title(raw_title, raw_description, user_note)


def generate_smart_reel_content(
    url: str,
    meta: Dict[str, str],
    user_note: Optional[str] = None,
    timeout: int = 40
) -> Tuple[str, str]:
    """
    Generate both an AI-edited smart Reel title and high-engagement Ukrainian Tech Lead description
    from URL metadata and user notes in a single prompt.
    Falls back gracefully if AI is unavailable or fails.
    """
    raw_title = clean_web_title(meta.get("title") or "")
    raw_desc = (meta.get("description") or "").strip()
    clean_note = (user_note or "").strip()

    if os.environ.get("FB_DISABLE_AI") == "1":
        return _fallback_format_reel_from_url(url, meta, user_note)

    agy_path = get_agy_path()
    if agy_path:
        prompt = (
            "Ти український інженер-практик та Tech Lead Василь (@vasylai_official).\n"
            "Твоє завдання: створити чіпку, професійну та вірусну назву і опис для Facebook Reels на основі матеріалу за посиланням.\n\n"
            f"Оригінальна назва: {raw_title or 'Матеріал'}\n"
        )
        if raw_desc:
            prompt += f"Контекст/анотація: {raw_desc[:400]}\n"
        if clean_note:
            prompt += f"Нотатка автора: {clean_note[:200]}\n"
        prompt += f"URL: {url}\n"

        prompt += (
            "\nВИМОГИ ДО НАЗВИ:\n"
            "- Мова: виключно українська.\n"
            "- Тон: авторитетний український Tech Lead (інтрига, розбір під капотом, без дешевого клікбейту).\n"
            "- Довжина: від 30 до 75 символів.\n"
            "- Якщо оригінал англійською — обов'язково переклади та адаптуй технічний зміст українською.\n\n"
            "ВИМОГИ ДО ОПИСУ:\n"
            "- Мова: українська.\n"
            "- Структура: короткий вступ-хук (1-2 речення), 2-3 конкретні тези/булети, та одне відкрите запитання до інженерів у кінці.\n"
            "- Довжина: до 350 символів (без хештегів та посилання, їх ми додамо автоматично).\n\n"
            "ФОРМАТ ВІДПОВІДІ (строго дотримуйся цього шаблону, без лапок):\n"
            "НАЗВА: <текст назви>\n"
            "ОПИС: <текст опису>"
        )

        try:
            res = subprocess.run(
                [agy_path, "--dangerously-skip-permissions", "-p", prompt],
                capture_output=True,
                text=True,
                timeout=timeout
            )
            if res.returncode == 0 and res.stdout:
                output = _clean_ai_output(res.stdout)
                title_match = re.search(r'(?:НАЗВА|TITLE|ЗАГОЛОВОК):\s*(.*?)(?=\n(?:ОПИС|DESCRIPTION):|$)', output, re.IGNORECASE | re.DOTALL)
                desc_match = re.search(r'(?:ОПИС|DESCRIPTION):\s*(.*)', output, re.IGNORECASE | re.DOTALL)

                parsed_title = ""
                parsed_desc = ""

                if title_match:
                    parsed_title = title_match.group(1).strip().split('\n')[0].strip()
                if desc_match:
                    parsed_desc = desc_match.group(1).strip()

                if not parsed_title and "\n\n" in output:
                    parts = output.split("\n\n", 1)
                    parsed_title = parts[0].strip().split('\n')[0].strip()
                    parsed_desc = parts[1].strip()

                parsed_title = re.sub(r'^(?:НАЗВА|TITLE|ЗАГОЛОВОК)[:\s\-]+', '', parsed_title, flags=re.IGNORECASE).strip()
                parsed_desc = re.sub(r'^(?:ОПИС|DESCRIPTION)[:\s\-]+', '', parsed_desc, flags=re.IGNORECASE).strip()

                if parsed_title and len(parsed_title) >= 6:
                    smart_title = parsed_title[:95]
                    body_parts = []
                    if parsed_desc:
                        body_parts.append(parsed_desc)
                    elif clean_note:
                        body_parts.append(clean_note)
                    elif raw_desc:
                        body_parts.append(raw_desc)

                    body_parts.append(f"🔗 Джерело: {url}")
                    body_parts.append("#TechLead #SoftwareEngineering #Architecture #AI #DevTools")
                    formatted_desc = "\n\n".join(body_parts)
                    return smart_title, formatted_desc
        except Exception:
            pass

    return _fallback_format_reel_from_url(url, meta, user_note)


def _fallback_format_reel_from_url(
    url: str,
    meta: Dict[str, str],
    user_note: Optional[str] = None
) -> Tuple[str, str]:
    """Deterministic fallback Reel formatter from URL."""
    raw_title = meta.get("title") or "Огляд технологій від Tech Lead"
    clean_title = _fallback_edit_title(raw_title, meta.get("description"), user_note)
    desc_meta = (meta.get("description") or "").strip()

    parts = []
    if user_note and user_note.strip():
        parts.append(user_note.strip())

    if desc_meta:
        parts.append(desc_meta)

    parts.append(f"🔗 Джерело: {url}")
    parts.append("#TechLead #SoftwareEngineering #Architecture #AI #DevTools")

    formatted_desc = "\n\n".join(str(p) for p in parts if p)
    return clean_title, formatted_desc


def format_reel_from_url(
    url: str,
    meta: Dict[str, str],
    user_note: Optional[str] = None,
    smart_ai: bool = True
) -> Tuple[str, str]:
    """
    Format Reel title and description using extracted URL metadata and optional user note.
    By default (smart_ai=True), uses AI ('agy') to intelligently edit the title and generate
    an expert Ukrainian Tech Lead description.
    Falls back to deterministic heuristic formatting if AI is offline or smart_ai=False.
    """
    if smart_ai and os.environ.get("FB_DISABLE_AI") != "1":
        return generate_smart_reel_content(url, meta, user_note=user_note)
    return _fallback_format_reel_from_url(url, meta, user_note=user_note)


