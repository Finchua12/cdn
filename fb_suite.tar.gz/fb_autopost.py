#!/usr/bin/env python3
"""
Facebook 6-Post Autopost Daemon — Василь Tech Lead
Automates daily publishing across 6 strategic time slots with high-impact engineering content.
"""

import os
import sys
import re
import json
import uuid
import time
import fcntl
import argparse
import urllib.request
import urllib.parse
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Union, Dict, Any, Optional, List

try:
    from zoneinfo import ZoneInfo
    KYIV_TZ = ZoneInfo("Europe/Kyiv")
except Exception:
    KYIV_TZ = timezone(timedelta(hours=3))

# Ensure bin directory is in sys.path for importing fb_post
_BIN_DIR = Path(__file__).resolve().parent
if str(_BIN_DIR) not in sys.path:
    sys.path.insert(0, str(_BIN_DIR))

try:
    from fb_utils import load_env, mask_token, sanitize_text, ENV_FILE
    import fb_post
    import fb_signals
    import fb_visual
except ImportError:
    from bin.fb_utils import load_env, mask_token, sanitize_text, ENV_FILE
    from bin import fb_post
    from bin import fb_signals
    try:
        from bin import fb_visual
    except ImportError:
        fb_visual = None

load_env()

HISTORY_FILE = Path(os.environ.get("FB_AUTOPOST_HISTORY_FILE", Path.home() / ".config" / "facebook" / "fb_autopost_history.json"))


def fetch_it_signals() -> List[str]:
    """
    Fetch live IT headlines from DOU (dou.ua) and dev.ua RSS feeds.
    Returns cleaned list of topics for high-engagement discussion posts.
    """
    signals = []
    feeds = [
        ("DOU", "https://dou.ua/feed/"),
        ("dev.ua", "https://dev.ua/rss")
    ]
    for source, url in feeds:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) VasylAIBot/1.0"}
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                xml_data = resp.read().decode("utf-8", errors="ignore")
                titles = re.findall(r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", xml_data, re.DOTALL)
                # Skip the first title (channel title), take top 5 news
                for t in titles[1:6]:
                    clean_t = re.sub(r"<[^>]+>", "", t).strip()
                    clean_t = clean_t.replace("&quot;", '"').replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&#039;", "'").replace("\xa0", " ")
                    if clean_t and len(clean_t) > 12:
                        signals.append(f"[{source}] {clean_t}")
        except Exception:
            pass
    return signals


def get_kyiv_now() -> datetime:
    """Return current datetime in Europe/Kyiv timezone."""
    return datetime.now(KYIV_TZ)


def load_history(history_path: Optional[Path] = None) -> Dict[str, Any]:
    """Load publication history with shared lock."""
    target = history_path or HISTORY_FILE
    if not target.exists():
        return {"published": []}
    try:
        with open(target, "r", encoding="utf-8") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
            except Exception:
                pass
            try:
                return json.load(f)
            finally:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except Exception:
                    pass
    except Exception:
        return {"published": []}


def save_history(data: Dict[str, Any], history_path: Optional[Path] = None) -> None:
    """Save publication history atomically with exclusive lock."""
    target = history_path or HISTORY_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_target = target.with_name(f"{target.stem}_{uuid.uuid4().hex[:8]}.tmp")
    with open(temp_target, "w", encoding="utf-8") as f:
        try:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        except Exception:
            pass
        try:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        finally:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
    temp_target.replace(target)


def is_slot_published_today(
    slot_idx: int,
    target_date: Optional[str] = None,
    history_path: Optional[Path] = None
) -> bool:
    """Check if slot_idx has already been published today."""
    today = target_date or get_kyiv_now().strftime("%Y-%m-%d")
    hist = load_history(history_path)
    for item in hist.get("published", []):
        if item.get("date") == today and item.get("slot") == slot_idx:
            return True
    return False


def record_publication(
    slot_idx: int,
    topic: str,
    post_id: str,
    history_path: Optional[Path] = None
) -> None:
    """Record published post in history (keeping last 100 entries)."""
    target = history_path or HISTORY_FILE
    hist = load_history(target)
    now_k = get_kyiv_now()
    entry = {
        "date": now_k.strftime("%Y-%m-%d"),
        "time": now_k.strftime("%H:%M:%S"),
        "slot": slot_idx,
        "topic": topic,
        "post_id": str(post_id),
        "timestamp": int(now_k.timestamp())
    }
    published = hist.get("published", [])
    published.append(entry)
    if len(published) > 100:
        published = published[-100:]
    hist["published"] = published
    save_history(hist, target)



## 9-slot daily schedule matrix (6 image slots + 3 text-only discussion slots)
SLOTS: List[Dict[str, Any]] = [
    {
        "slot": 0,
        "time": "08:00",
        "category": "opensource",
        "theme": "Свіжий Open-Source реліз #1",
        "name": "opensource_1",
        "format": "image",
        "tag": "#OpenSource",
        "tags": "#OpenSource #DevTools #GitHub #Coding #TechLead",
        "default_hook": "🛠️ Свіжий Open-Source реліз, вартий уваги кожного розробника:",
        "default_question": "💬 Чи доводилося вам тестувати це рішення у своїх робочих проєктах?",
    },
    {
        "slot": 1,
        "time": "09:45",
        "category": "ai_news",
        "theme": "Головні ШІ-новини індустрії #1",
        "name": "ai_news_1",
        "format": "image",
        "tag": "#AI",
        "tags": "#AI #MachineLearning #LLM #DeepLearning #TechLead",
        "default_hook": "🤖 Головна технологічна подія дня в індустрії AI:",
        "default_question": "💬 Що думаєте про цей анонс: реальний прорив чи маркетинговий хайп?",
    },
    {
        "slot": 2,
        "time": "11:30",
        "category": "text",
        "theme": "Ранковий архітектурний розбір",
        "name": "architecture_text",
        "format": "text",
        "tag": "#Architecture",
        "tags": "#Architecture #CleanCode #SoftwareEngineering #SystemDesign",
        "default_topics": [
            "Outbox Pattern: як гарантувати доставку подій у розподілених системах без розподілених транзакцій",
            "Моноліт vs Мікросервіси в 2026: чому повернення до модульного моноліту економить мільйони",
            "Cache Invalidation на практиці: чому TTL це не стратегія, а молитва",
            "Event-Driven Architecture: коли черги Kafka стають вашим головним болем",
        ],
        "default_hook": "🏗️ Чистий код у книжках vs реальність під високим навантаженням:",
        "default_points": [
            "Книжковий Clean Architecture часто створює 5 шарів абстракцій там, де вистачило б 1 простого сервісу.",
            "Розподілені транзакції (2PC) вбивають latency; transactional outbox патерн рятує консистентність без блокувань.",
            "Пул з'єднань з базою — це перший вузький вузол: краще 20 швидких з'єднань, ніж 500 завислих у черзі.",
            "Справжня якість архітектури вимірюється не кількістю інтерфейсів, а швидкістю онбордингу та часом відновлення (MTTR)."
        ],
        "default_question": "💬 А який архітектурний компроміс у вашому поточному проєкті ви вважаєте найбільш спірним?",
    },
    {
        "slot": 3,
        "time": "13:15",
        "category": "opensource",
        "theme": "Свіжий Open-Source реліз #2",
        "name": "opensource_2",
        "format": "image",
        "tag": "#OpenSource",
        "tags": "#OpenSource #Backend #Database #DevTools #TechLead",
        "default_hook": "🛠️ Потужний опенсорс інструмент для щоденного бекенду:",
        "default_question": "💬 Чи готові замінити платні хмарні сервіси на цей відкритий інструмент?",
    },
    {
        "slot": 4,
        "time": "15:00",
        "category": "ai_news",
        "theme": "Головні ШІ-новини індустрії #2",
        "name": "ai_news_2",
        "format": "image",
        "tag": "#AI",
        "tags": "#AI #LLM #Automation #FutureOfWork #TechLead",
        "default_hook": "🤖 Тектонічний зсув в інженерному стеку штучного інтелекту:",
        "default_question": "💬 Як цей реліз вплине на ваш стек та робочі процеси в команді?",
    },
    {
        "slot": 5,
        "time": "16:45",
        "category": "text",
        "theme": "Гострий інженерний холівар",
        "name": "engineering_holivar",
        "format": "text",
        "tag": "#TechDebate",
        "tags": "#TechDebate #Coding #SoftwareEngineering #TechLead",
        "default_topics": [
            "Чи тупіють програмісти від AI-асистентів: Cursor, Claude та втрата розуміння кодової бази",
            "ORM проти Raw SQL: коли магія фреймворків починає коштувати занадто дорого",
            "Покриття тестами на 100%: інженерна дисципліна чи марна трата бюджету компанії",
            "Аналіз продуктивності Bun проти Node.js на високих навантаженнях",
        ],
        "default_hook": "⚡ Гострий інженерний холівар, який розколює будь-який розробницький чат:",
        "default_points": [
            "Коли генератор коду пише за вас 80% логіки, ви втрачаєте ментальну модель проєкту і не можете здебажити баг о другій ночі.",
            "Сліпе дотримання догм (наприклад, 100% test coverage) часто веде до тестування деталей реалізації замість бізнес-поведінки.",
            "Найкращі розробники використовують інструменти як підсилювач власної експертизи, а не як заміну вмінню думати.",
            "Простота та читабельність коду завжди б'ють передчасну оптимізацію та надумані паттерни проектування."
        ],
        "default_question": "💬 На чиєму ви боці у цій суперечці: суворе дотримання догм чи прагматичний компроміс?",
    },
    {
        "slot": 6,
        "time": "18:30",
        "category": "opensource",
        "theme": "Свіжий Open-Source реліз #3",
        "name": "opensource_3",
        "format": "image",
        "tag": "#DevTools",
        "tags": "#DevTools #OpenSource #Linux #Productivity #TechLead",
        "default_hook": "🛠️ Відкритий інструмент дня для оптимізації продакшену:",
        "default_question": "💬 Які CLI чи DevTools з опенсорсу додали у свій щоденний термінал останнім часом?",
    },
    {
        "slot": 7,
        "time": "20:15",
        "category": "ai_news",
        "theme": "Головні ШІ-новини індустрії #3",
        "name": "ai_news_3",
        "format": "image",
        "tag": "#AI",
        "tags": "#AI #DeepLearning #Research #Innovation #TechLead",
        "default_hook": "🤖 Інженерний розбір головного ШІ-релізу дня:",
        "default_question": "💬 Яку модель чи інструмент із сьогоднішніх новин плануєте помацати в терміналі першим?",
    },
    {
        "slot": 8,
        "time": "22:00",
        "category": "text",
        "theme": "Вечірня інженерна філософія та кар'єра",
        "name": "career_philosophy",
        "format": "text",
        "tag": "#TechLead",
        "tags": "#TechLead #CareerGrowth #LifeInTech #EngineeringCulture",
        "default_topics": [
            "Вигорання в IT: як розпізнати межу, коли код перестає приносити задоволення",
            "Чи є життя після 35 в розробці: менеджмент, архітектура чи вічний синьйор-кодер",
            "Пет-проєкти проти відпочинку: чи повинен розробник кодити вечорами заради кар'єри",
            "Смерть одноденних фреймворків: чому фундаментальні знання Linux та протоколів цінніші за хайп",
        ],
        "default_hook": "🌙 Вечірня інженерна філософія: про що мовчать на стендапах:",
        "default_points": [
            "Виснаження настає не від кількості написаних рядків коду, а від відчуття беззмістовності поставлених задач.",
            "Справжнє сеньйорство — це вміння сказати «ні» зайвій фічі або надмірному ускладненню архітектури ще до першого коміту.",
            "Баланс між роботою та життям — це не слабкість, а єдиний спосіб залишатися ефективним інженером на дистанції в 10+ років."
        ],
        "default_question": "💬 Як ви справляєтеся з перевантаженням та рутиною, коли накопичується втома від проєкту?",
    },
]


def resolve_slot(slot: Union[int, str]) -> Dict[str, Any]:
    """Resolve a slot index or name/theme string to slot definition."""
    if isinstance(slot, int):
        if 0 <= slot < len(SLOTS):
            return SLOTS[slot]
        raise ValueError(f"Невірний номер слоту: {slot}. Очікується 0-{len(SLOTS)-1}.")

    if isinstance(slot, str):
        slot_clean = slot.strip()
        # Case 1: String digit
        if slot_clean.isdigit():
            idx = int(slot_clean)
            if 0 <= idx < len(SLOTS):
                return SLOTS[idx]
            raise ValueError(f"Невірний номер слоту: {idx}. Очікується 0-{len(SLOTS)-1}.")

        # Case 2: Time match (e.g. "08:30")
        for s in SLOTS:
            if s["time"] == slot_clean:
                return s

        # Case 3: Name match (exact or substring, e.g. "architecture", "ai_news")
        for s in SLOTS:
            if s["name"].lower() == slot_clean.lower() or slot_clean.lower() in s["name"].lower():
                return s

        # Case 4: Substring in theme
        for s in SLOTS:
            if slot_clean.lower() in s["theme"].lower() or s["theme"].lower() in slot_clean.lower():
                return s

        raise ValueError(f"Не вдалося знайти слот за ідентифікатором: '{slot}'.")

    raise ValueError(f"Неприпустимий тип для слоту: {type(slot)}.")


def get_current_slot_index(now_dt: Optional[datetime] = None) -> int:
    """
    Determine the best slot index (0-8) based on Kyiv local time.
    Uses circular minute distance across a 24-hour cycle (1440 mins).
    """
    if now_dt is None:
        dt = get_kyiv_now()
    elif now_dt.tzinfo is not None and KYIV_TZ is not None:
        dt = now_dt.astimezone(KYIV_TZ)
    else:
        dt = now_dt

    current_minutes = dt.hour * 60 + dt.minute

    slot_minutes = [
        8 * 60 + 0,    # 08:00 -> 480 (Slot 0, opensource image)
        9 * 60 + 45,   # 09:45 -> 585 (Slot 1, ai_news image)
        11 * 60 + 30,  # 11:30 -> 690 (Slot 2, architecture text)
        13 * 60 + 15,  # 13:15 -> 795 (Slot 3, opensource image)
        15 * 60 + 0,   # 15:00 -> 900 (Slot 4, ai_news image)
        16 * 60 + 45,  # 16:45 -> 1005 (Slot 5, holivar text)
        18 * 60 + 30,  # 18:30 -> 1110 (Slot 6, opensource image)
        20 * 60 + 15,  # 20:15 -> 1215 (Slot 7, ai_news image)
        22 * 60 + 0,   # 22:00 -> 1320 (Slot 8, career text)
    ]

    def circ_diff(m1: int, m2: int) -> int:
        d = abs(m1 - m2)
        return min(d, 1440 - d)

    best_slot = 0
    best_diff = 1440
    for idx, s_min in enumerate(slot_minutes):
        diff = circ_diff(current_minutes, s_min)
        if diff < best_diff:
            best_diff = diff
            best_slot = idx

    return best_slot


def generate_post_for_slot(
    slot: Union[int, str],
    topic: Optional[str] = None
) -> Dict[str, Any]:
    """
    Synthesize an expert Facebook post adhering to Ukrainian 'Василь Tech Lead' persona
    and Zero Link Penalty guidelines:
    - 3 Open-Source slots (slots 0, 3, 6): mature high-impact repo (>=5000 stars), link in comment, #OpenSource / #DevTools
    - 3 AI News slots (slots 1, 4, 7): live AI engineering insight, link in comment, #AI
    - 3 Text slots (slots 2, 5, 8): deep engineering debate, architecture, career, text-only
    """
    slot_info = resolve_slot(slot)
    slot_idx = slot_info["slot"]
    slot_category = slot_info.get("category", "text")
    slot_format = slot_info.get("format", "image")

    hist = load_history()
    used_topics = {item.get("topic") for item in hist.get("published", [])}
    day_of_year = get_kyiv_now().timetuple().tm_yday

    if slot_category == "opensource":
        if topic:
            repo_data = {
                "name": topic.strip(),
                "topic": topic.strip(),
                "full_name": topic.strip(),
                "url": f"https://github.com/search?q={urllib.parse.quote(topic.strip())}",
                "description": f"Опенсорс інструмент {topic.strip()}",
                "stars": 1500,
                "language": "Python"
            }
        else:
            repos = fb_signals.fetch_recent_opensource_projects()
            unused = [r for r in repos if r.get("name") not in used_topics and r.get("full_name") not in used_topics]
            pool = unused if unused else repos
            repo_data = pool[(day_of_year + slot_idx) % len(pool)]

        post_obj = fb_signals.format_opensource_post(repo_data)
        return {
            "slot": slot_idx,
            "category": "opensource",
            "format": slot_format,
            "time": slot_info["time"],
            "theme": slot_info["theme"],
            "topic": post_obj["topic"],
            "hook": post_obj.get("hook", f"🛠️ {post_obj['topic']}"),
            "points": post_obj["points"],
            "question": post_obj["question"],
            "tags": slot_info.get("tag", "#OpenSource"),
            "content": post_obj["content"],
            "comment": post_obj["comment"]
        }

    elif slot_category == "ai_news":
        if topic:
            news_data = {
                "title": topic.strip(),
                "topic": topic.strip(),
                "summary": f"Аналіз технологічного анонсу {topic.strip()}",
                "url": "https://news.ycombinator.com",
                "source": "AI Industry"
            }
        else:
            news_list = fb_signals.fetch_recent_ai_news()
            unused = [n for n in news_list if n.get("title") not in used_topics]
            pool = unused if unused else news_list
            news_data = pool[(day_of_year + slot_idx) % len(pool)]

        post_obj = fb_signals.format_ai_news_post(news_data)
        return {
            "slot": slot_idx,
            "category": "ai_news",
            "format": slot_format,
            "time": slot_info["time"],
            "theme": slot_info["theme"],
            "topic": post_obj["topic"],
            "hook": post_obj.get("hook", f"🤖 {post_obj['topic']}"),
            "points": post_obj["points"],
            "question": post_obj["question"],
            "tags": slot_info.get("tag", "#AI"),
            "content": post_obj["content"],
            "comment": post_obj["comment"]
        }

    else:
        # category == "text" (architecture, holivar, career philosophy)
        if topic:
            selected_topic = topic.strip()
        else:
            default_topics = slot_info.get("default_topics", [])
            unused_topics = [t for t in default_topics if t not in used_topics]
            if unused_topics:
                selected_topic = unused_topics[(day_of_year + slot_idx) % len(unused_topics)]
            elif default_topics:
                selected_topic = default_topics[(day_of_year + slot_idx) % len(default_topics)]
            else:
                selected_topic = slot_info["theme"]

        if topic:
            hook = f"🔥 {selected_topic}: розбір від практика без маркетингової води"
            points = [
                f"Аналізуємо архітектурне ядро: як {selected_topic} веде себе під навантаженням та які приховані ботлнеки виникають.",
                f"Реальні метрики: різниця між синтетичними бенчмарками та продакшеном становить до 40% через overhead мережі та серіалізацію.",
                f"Практичний досвід: замість передчасної оптимізації фокусуємося на ізоляції контекстів та детермінованих тестах.",
                f"Головне правило техліда: будь-яка зміна стеку повинна вирішувати конкретний бізнес-біль, а не закривати чийсь кар'єрний інтерес."
            ]
            question = f"💬 А який у вас досвід роботи з {selected_topic}? Які підводні камені вилазили на проді?"
        else:
            hook = slot_info.get("default_hook", f"🔥 {selected_topic}:")
            points = slot_info.get("default_points", [])
            question = slot_info.get("default_question", "💬 А як ви вирішуєте це у своїх проєктах?")

        if not question.strip().endswith("?"):
            question = question.rstrip(".! ") + "?"

        tag = slot_info.get("tag", "#SoftwareEngineering")

        formatted_points = "\n\n".join(points)
        full_content = (
            f"{hook}\n\n"
            f"{selected_topic}\n\n"
            f"{formatted_points}\n\n"
            f"{question}\n\n"
            f"{tag}"
        )

        return {
            "slot": slot_idx,
            "category": "text",
            "format": slot_format,
            "time": slot_info["time"],
            "theme": slot_info["theme"],
            "topic": selected_topic,
            "hook": hook,
            "points": points,
            "question": question,
            "tags": tag,
            "content": full_content,
        }


def run_slot(
    slot: Union[int, str],
    dry_run: bool = False,
    topic: Optional[str] = None,
    image_path: Optional[Union[str, Path]] = None,
    page_id: Optional[str] = None,
    token: Optional[str] = None,
    auto_visual: bool = True,
    force: bool = False
) -> Dict[str, Any]:
    """
    Execute a scheduled autopost slot.
    Generates content and dispatches to fb_post module (or previews in dry-run mode).
    If auto_visual is True and no image_path is provided, generates a themed visual card for image slots.
    Text slots (slots 2, 3, 5) publish text posts without images by default.
    """
    slot_info = resolve_slot(slot)
    slot_idx = slot_info["slot"]
    slot_format = slot_info.get("format", "image")

    # Guard against duplicate publication of the same slot on the same day
    if not dry_run and not force:
        today_str = get_kyiv_now().strftime("%Y-%m-%d")
        if is_slot_published_today(slot_idx, target_date=today_str):
            print(f"⚠️ Слот #{slot_idx} ({slot_info['time']}) вже опубліковано сьогодні ({today_str}). Пропускаємо для захисту від дублікатів.", file=sys.stderr)
            return {
                "slot": slot_idx,
                "time": slot_info["time"],
                "theme": slot_info["theme"],
                "skipped": True,
                "reason": "already_published_today"
            }

    post_data = generate_post_for_slot(slot_info["slot"], topic=topic)
    result = dict(post_data)

    # Determine post type:
    # 1. If explicit image_path provided -> publish with image
    # 2. If format is "text" -> text post (no image)
    # 3. If auto_visual is False -> text post
    # 4. Otherwise (format is "image" and auto_visual is True) -> generate visual and publish photo
    is_text_post = (slot_format == "text") or (not auto_visual)
    if image_path:
        is_text_post = False

    print("=" * 65)
    print(f"⏰ Слот #{slot_info['slot']} ({slot_info['time']}) — {slot_info['theme']}")
    print(f"🎯 Тема: {post_data['topic']}")
    print(f"📝 Текст ({len(post_data['content'])} симв.):\n{post_data['content'][:200]}...")

    # Automatically generate themed visual card if image slot and no custom image provided
    if not is_text_post and not image_path and not dry_run:
        try:
            try:
                import fb_visual
            except ImportError:
                from bin import fb_visual
            print("🎨 Автоматична генерація тематичного візуалу...")
            image_path = fb_visual.generate_post_image(
                topic=post_data["topic"],
                theme=slot_info.get("theme", ""),
                slot_name=slot_info.get("name", ""),
                points=post_data.get("points", [])
            )
            print(f"✓ Візуал успішно згенеровано: {image_path}")
        except Exception as e:
            print(f"⚠️ Не вдалося згенерувати візуал ({e}), публікуємо як текстовий пост.")
            image_path = None

    if image_path:
        result["image_path"] = str(image_path)
        print(f"🖼 Зображення: {image_path}")
    elif not is_text_post:
        print("🖼 Формат: Пост із зображенням (3D-візуал через agy, очищення метаданих C2PA)")
    else:
        print("💬 Формат: Текстовий допис без зображення (дискусія для максимального залучення коментарів)")
    print("=" * 65)

    if dry_run:
        print("🔍 [DRY-RUN] Публікацію пропущено (симуляція успіху).")
        if post_data.get("comment"):
            print(f"💬 [DRY-RUN] Перший коментар (Zero Link Penalty):\n{post_data['comment']}")
        result["dry_run"] = True
        result["published"] = False
        result["status"] = "dry_run"
        return result

    # Live publishing via fb_post
    result["dry_run"] = False
    kwargs = {}
    if page_id:
        kwargs["page_id"] = page_id
    if token:
        kwargs["token"] = token

    try:
        if image_path:
            print("📤 Публікація фото-посту через fb_post.publish_photo...")
            api_resp = fb_post.publish_photo(
                image_path,
                caption=post_data["content"],
                **kwargs
            )
        else:
            print("📤 Публікація текстового посту через fb_post.publish_text...")
            api_resp = fb_post.publish_text(
                post_data["content"],
                **kwargs
            )

        post_id = api_resp.get("post_id") or api_resp.get("id")
        result["published"] = True
        result["post_id"] = post_id
        result["api_response"] = api_resp
        if post_id and not dry_run:
            record_publication(slot_idx, post_data["topic"], post_id)
        print(f"🎉 УСПІХ! Опубліковано у Facebook. Post ID: {post_id}")

        # Zero Link Penalty: immediately post link in the first comment under the post
        comment_text = post_data.get("comment")
        if comment_text and post_id and not dry_run:
            print(f"\n💬 Публікація першого коментаря з посиланням (Zero Link Penalty) під постом {post_id}...")
            time.sleep(2)
            try:
                c_resp = fb_post.publish_comment(post_id, comment_text, **kwargs)
                comment_id = c_resp.get("id")
                result["comment_id"] = comment_id
                print(f"✓ Перший коментар успішно опубліковано! ID: {comment_id}")
            except Exception as ce:
                clean_ce = sanitize_text(str(ce))
                print(f"⚠️ Попередження: пост опубліковано ({post_id}), але не вдалося додати перший коментар: {clean_ce}", file=sys.stderr)
                # Fallback: if comment could not be published, update the post directly with the link
                try:
                    url_match = re.search(r'https?://[^\s]+', comment_text)
                    raw_url = url_match.group(0) if url_match else post_data.get("url", "")
                    if raw_url:
                        print(f"🔄 Спроба резервного оновлення посту {post_id} з прямим посиланням...")
                        updated_content = post_data["content"]
                        updated_content = re.sub(
                            r'\(🔗\s*посилання на [^)]+ залишив у першому коментарі\s*👇?\)',
                            f'(🔗 {raw_url})',
                            updated_content
                        )
                        fb_post.update_post(post_id, updated_content, **kwargs)
                        print("✓ Пост успішно оновлено з прямим лінком як резервний варіант.")
                except Exception as fe:
                    print(f"⚠️ Резервне оновлення посту також не вдалося: {sanitize_text(str(fe))}", file=sys.stderr)

        return result
    except Exception as e:
        clean_err = sanitize_text(str(e))
        print(f"❌ Помилка під час публікації слоту #{slot_info['slot']}: {clean_err}", file=sys.stderr)
        raise


def main():
    parser = argparse.ArgumentParser(
        description="Facebook 9-Post Autopost Daemon — Василь Tech Lead (6 зображень + 3 текстові дискусії)"
    )
    parser.add_argument(
        "--slot", "-s",
        type=int,
        choices=range(0, 9),
        help="Номер слоту розкладу (0-8: 6 із зображеннями + 3 текстові дискусії)"
    )
    parser.add_argument(
        "--now",
        action="store_true",
        help="Автоматично обрати слот за поточним системним часом"
    )
    parser.add_argument(
        "--topic", "-t",
        type=str,
        help="Кастомна інженерна тема для публікації"
    )
    parser.add_argument(
        "--image", "-i",
        type=str,
        help="Шлях до зображення (JPEG, PNG)"
    )
    parser.add_argument(
        "--no-image",
        action="store_true",
        help="Публікувати виключно як текстовий пост (без генерації зображення)"
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Примусово опублікувати слот, навіть якщо він вже був опублікований сьогодні"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Тестовий режим без відправки в Meta API"
    )

    args = parser.parse_args()

    slot_idx = args.slot
    if slot_idx is None:
        if args.now or args.topic or args.dry_run:
            slot_idx = get_current_slot_index()
            print(f"🕒 Автовизначення слоту за поточним часом: обрано слот #{slot_idx} ({SLOTS[slot_idx]['time']})")
        else:
            parser.print_help()
            sys.exit(1)

    try:
        run_slot(
            slot=slot_idx,
            dry_run=args.dry_run,
            topic=args.topic,
            image_path=args.image,
            auto_visual=not args.no_image,
            force=args.force
        )
    except Exception as e:
        clean_err = sanitize_text(str(e))
        print(f"\n❌ Збій виконання демона fb_autopost: {clean_err}", file=sys.stderr)
        sys.exit(1)



if __name__ == "__main__":
    main()
