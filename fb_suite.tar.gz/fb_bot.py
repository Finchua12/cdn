#!/usr/bin/env python3
"""
Interactive Telegram Bot Daemon (@AutoFaceB_bot) — Facebook Automation Suite
Handles Telegram updates via long polling, verifies strict admin authorization,
receives and queues .mp4 videos for Reels, provides inline keyboard controls
(Publish / Edit Description / Cancel), performs async Graph API publishing,
and exposes on-demand commands (/start, /post, /stats).
"""

import os
import sys
import json
import time
import uuid
import signal
import re
import threading
import argparse
import fcntl
import shutil
from pathlib import Path
from typing import Optional, Union, Dict, Any, List
import html
import urllib.request
import urllib.parse
import urllib.error

# Ensure bin directory is in sys.path
_BIN_DIR = Path(__file__).resolve().parent
if str(_BIN_DIR) not in sys.path:
    sys.path.insert(0, str(_BIN_DIR))

try:
    import fb_utils
    from fb_utils import load_env, mask_token, sanitize_text, ENV_FILE
    import publish_reel
    import fb_post
    import fb_autopost
    import fb_engage
except ImportError:
    import bin.fb_utils as fb_utils
    from bin.fb_utils import load_env, mask_token, sanitize_text, ENV_FILE
    from bin import publish_reel, fb_post, fb_autopost, fb_engage

load_env()

QUEUE_DIR = Path("/tmp/fb_reels_queue")
QUEUE_FILE = Path(os.environ.get("FB_REELS_QUEUE_FILE", os.path.expanduser("~/.config/facebook/fb_reels_queue.json")))
TELEGRAM_API_URL = os.environ.get("TELEGRAM_API_URL", "https://api.telegram.org").rstrip("/")

BOT_TOKEN = os.environ.get("FB_TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_CHAT_ID = os.environ.get("FB_ADMIN_CHAT_ID", "792301169").strip()
PAGE_ID = os.environ.get("FB_PAGE_ID", "1299711009894993").strip()
PAGE_TOKEN = os.environ.get("FB_PAGE_ACCESS_TOKEN", "").strip()
PAGE_NAME = os.environ.get("FB_PAGE_NAME", "Василь Tech Lead").strip()

# In-memory states
REELS_QUEUE: Dict[str, Dict[str, Any]] = {}
USER_STATES: Dict[int, Dict[str, Any]] = {}
RUNNING = True


def load_reels_queue(queue_file: Optional[Path] = None) -> Dict[str, Dict[str, Any]]:
    """Load reels queue state from disk with shared lock (LOCK_SH)."""
    target = queue_file or QUEUE_FILE
    if not target.exists():
        return {}
    try:
        with open(target, "r", encoding="utf-8") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
            except Exception:
                pass
            try:
                data = json.load(f)
                if isinstance(data, dict):
                    for v in data.values():
                        if isinstance(v, dict) and "path" in v and isinstance(v["path"], str):
                            v["path"] = Path(v["path"])
                    return data
            finally:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except Exception:
                    pass
    except Exception:
        pass
    return {}


def save_reels_queue(queue_data: Dict[str, Dict[str, Any]], queue_file: Optional[Path] = None) -> None:
    """Save reels queue state to disk atomically with exclusive lock (LOCK_EX)."""
    target = queue_file or QUEUE_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    serializable = {}
    for k, v in queue_data.items():
        item_copy = dict(v)
        if "path" in item_copy and isinstance(item_copy["path"], Path):
            item_copy["path"] = str(item_copy["path"])
        serializable[k] = item_copy

    temp_path = target.with_name(f"{target.stem}_{uuid.uuid4().hex[:8]}.tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            except Exception:
                pass
            try:
                json.dump(serializable, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            finally:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except Exception:
                    pass
        temp_path.replace(target)
    except Exception as e:
        if temp_path.exists():
            temp_path.unlink(missing_ok=True)
        print(f"⚠️ Помилка збереження черги Reels: {e}", file=sys.stderr)


# Hydrate existing queue from disk on module import
try:
    REELS_QUEUE.update(load_reels_queue())
except Exception:
    pass


def is_authorized(
    chat_id: Optional[Union[int, str]],
    admin_id: Optional[Union[int, str]] = None
) -> bool:
    """Strict authorization check against FB_ADMIN_CHAT_ID."""
    if chat_id is None:
        return False
    aid = str(admin_id or ADMIN_CHAT_ID).strip()
    cid = str(chat_id).strip()
    return bool(cid and cid == aid)


GENERIC_NAME_PATTERN = re.compile(
    r'^(?:[0-9_\-\s\(\)]+|vid[_\-\d]+|video[_\-\d]*|screen[_\-\w]*|untitled[_\-\w]*|export[_\-\w]*)$',
    re.IGNORECASE
)


def is_generic_filename(filename: str) -> bool:
    """Check if filename is generic camera/export name (e.g. 0920 (1)(1), VID_20260920, screen-rec)."""
    base = Path(filename).name
    clean = re.sub(r'\.(?:mp4|mov|mkv|avi|m4v|webm)$', '', base, flags=re.IGNORECASE).strip()
    return bool(GENERIC_NAME_PATTERN.match(clean))


def clean_filename_to_title(filename: str, caption: Optional[str] = None) -> str:
    """
    Cleans underscores, strips known video extensions, and formats cleanly.
    If caption is provided and non-empty, the first line is extracted as title.
    If filename is generic and no caption is provided, falls back to a professional tech title.
    """
    if caption and caption.strip():
        first_line = caption.strip().split("\n", 1)[0].strip()
        # Clean leading/trailing markdown, quotes, emojis
        first_line = re.sub(r'^[\#\*\-\s\>]+', '', first_line).strip()
        if len(first_line) >= 3:
            return first_line[:100].strip()

    base = Path(filename).name
    # Strip video extensions
    base = re.sub(r'\.(?:mp4|mov|mkv|avi|m4v|webm)$', '', base, flags=re.IGNORECASE)

    if is_generic_filename(base):
        return "Архітектурний інсайт від Василя Tech Lead"

    # Replace underscores with spaces
    title = base.replace('_', ' ')
    # Normalize multiple whitespace
    title = ' '.join(title.split()).strip()
    return title


def generate_reel_description(title: str) -> str:
    """Generate high-impact Ukrainian Tech Lead description with hashtags."""
    return (
        f"🚀 {title}\n\n"
        "Розбираємо інженерні деталі, архітектурні патерни та реальний продакшен-досвід "
        "команди Василя Tech Lead. Практика без маркетингової води.\n\n"
        "#TechLead #SoftwareEngineering #Architecture #DevTools #AI #DevOps"
    )


def build_reel_keyboard(item_uuid: str) -> Dict[str, Any]:
    """Build inline keyboard for Reel review and publishing."""
    return {
        "inline_keyboard": [
            [{"text": "🚀 Опублікувати Reel", "callback_data": f"publish:{item_uuid}"}],
            [
                {"text": "🏷️ Змінити назву", "callback_data": f"title:{item_uuid}"},
                {"text": "✏️ Змінити опис", "callback_data": f"edit:{item_uuid}"}
            ],
            [
                {"text": "🪄 Перегенерувати AI", "callback_data": f"regen:{item_uuid}"},
                {"text": "❌ Скасувати", "callback_data": f"cancel:{item_uuid}"}
            ]
        ]
    }


def load_comment_replies_count(state_path: Optional[Path] = None) -> int:
    """Load total answered comments count from engagement state JSON."""
    try:
        st = fb_engage.load_state(state_path)
        return len(st.get("replied", []))
    except Exception:
        return 0


def telegram_api_request(
    method: str,
    params: Optional[Dict[str, Any]] = None,
    data: Optional[bytes] = None,
    headers: Optional[Dict[str, str]] = None,
    token: Optional[str] = None,
    timeout: int = 35
) -> Dict[str, Any]:
    """Execute Telegram Bot API HTTP request."""
    tok = token or BOT_TOKEN
    base_url = TELEGRAM_API_URL.rstrip("/")
    url = f"{base_url}/bot{tok}/{method}"

    req_headers = dict(headers or {})
    body = data

    if body is None and params is not None:
        body = json.dumps(params).encode("utf-8")
        req_headers["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=body, headers=req_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp_body = resp.read().decode("utf-8")
            return json.loads(resp_body)
    except urllib.error.HTTPError as e:
        err_msg = sanitize_text(e.read().decode("utf-8", errors="replace"), [tok])
        raise RuntimeError(f"Telegram API HTTP {e.code} error: {err_msg}") from None
    except Exception as e:
        clean_err = sanitize_text(str(e), [tok])
        raise RuntimeError(f"Telegram API request failed: {clean_err}") from None


def send_message(
    chat_id: Union[int, str],
    text: str,
    reply_markup: Optional[Dict[str, Any]] = None,
    parse_mode: Optional[str] = "HTML",
    token: Optional[str] = None
) -> Dict[str, Any]:
    """Send text message to Telegram user."""
    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "text": text,
    }
    if parse_mode:
        payload["parse_mode"] = parse_mode
    if reply_markup:
        payload["reply_markup"] = reply_markup

    return telegram_api_request("sendMessage", params=payload, token=token)


def edit_message_text(
    chat_id: Union[int, str],
    message_id: int,
    text: str,
    reply_markup: Optional[Dict[str, Any]] = None,
    parse_mode: Optional[str] = "HTML",
    token: Optional[str] = None
) -> Dict[str, Any]:
    """Edit existing text message."""
    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
    }
    if parse_mode:
        payload["parse_mode"] = parse_mode
    if reply_markup:
        payload["reply_markup"] = reply_markup

    return telegram_api_request("editMessageText", params=payload, token=token)


def answer_callback_query(
    callback_query_id: str,
    text: Optional[str] = None,
    show_alert: bool = False,
    token: Optional[str] = None
) -> Dict[str, Any]:
    """Acknowledge Telegram callback query."""
    payload: Dict[str, Any] = {
        "callback_query_id": callback_query_id,
        "show_alert": show_alert
    }
    if text:
        payload["text"] = text
    return telegram_api_request("answerCallbackQuery", params=payload, token=token)


def download_telegram_file(
    file_id: str,
    dest_path: Path,
    token: Optional[str] = None,
    timeout: int = 120
) -> Path:
    """Download Telegram file to local destination path."""
    tok = token or BOT_TOKEN
    file_info = telegram_api_request("getFile", params={"file_id": file_id}, token=tok)
    remote_path = file_info.get("result", {}).get("file_path")
    if not remote_path:
        raise RuntimeError(f"Could not resolve file_path for file_id {file_id}")

    dest_path.parent.mkdir(parents=True, exist_ok=True)

    # In local telegram-bot-api mode, remote_path can be an absolute path on disk
    if os.path.isabs(remote_path) and os.path.exists(remote_path):
        shutil.copyfile(remote_path, dest_path)
        return dest_path

    base_url = TELEGRAM_API_URL.rstrip("/")
    download_url = f"{base_url}/file/bot{tok}/{remote_path}"

    req = urllib.request.Request(download_url)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        with open(dest_path, "wb") as out_f:
            while chunk := resp.read(64 * 1024):
                out_f.write(chunk)

    return dest_path


def poll_reel_status(
    video_id: str,
    token: Optional[str] = None,
    max_attempts: int = 20,
    delay_seconds: float = 3.0
) -> Dict[str, Any]:
    """Poll Facebook Graph API until Reel video status is ready."""
    tok = token or PAGE_TOKEN
    url = f"https://graph.facebook.com/v19.0/{video_id}?fields=status&access_token={tok}"

    last_res: Dict[str, Any] = {}
    for _ in range(max_attempts):
        req = urllib.request.Request(url)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                res = json.loads(resp.read().decode("utf-8"))
                last_res = res
                status_obj = res.get("status", {})
                v_status = status_obj.get("video_status")
                pub_phase = status_obj.get("publishing_phase", {}).get("status")

                if v_status == "ready" or pub_phase == "complete":
                    return res

                if v_status in ["error", "rejected"] or pub_phase in ["error", "rejected"]:
                    raise RuntimeError(f"Facebook rejected Reel processing: {status_obj}")
        except urllib.error.HTTPError as e:
            raw_err = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Polling HTTP {e.code} error: {sanitize_text(raw_err, [tok])}") from None

        time.sleep(delay_seconds)

    return last_res


def cleanup_reels_queue_dir(queue_dir: Optional[Path] = None) -> int:
    """Scrub all orphaned video files in QUEUE_DIR that are not in REELS_QUEUE."""
    target_dir = queue_dir or QUEUE_DIR
    if not target_dir.exists():
        return 0

    active_paths = set()
    for item in REELS_QUEUE.values():
        p = item.get("path")
        if p:
            active_paths.add(Path(p).resolve())

    removed = 0
    now = time.time()
    for f in target_dir.glob("*.mp4"):
        f_res = f.resolve()
        if f_res not in active_paths or (now - f.stat().st_mtime > 7200):
            try:
                f.unlink(missing_ok=True)
                removed += 1
            except Exception:
                pass
    return removed


def execute_publish(
    item_uuid: str,
    chat_id: int,
    message_id: Optional[int] = None
) -> None:
    """Perform synchronous or async Reel publishing pipeline and notify user."""
    item = REELS_QUEUE.get(item_uuid)
    if not item:
        send_message(chat_id, "❌ Відео не знайдено в черзі (можливо, вже оброблено або скасовано).")
        return

    video_path: Path = item["path"]
    description: str = item["description"]
    title: str = item["title"]

    try:
        send_message(chat_id, f"⏳ Завантаження та публікація Reel «<b>{html.escape(title)}</b>» у Meta Graph API...")
        res = publish_reel.publish_reel(str(video_path), description=description, title=title)

        video_id = res.get("video_id") if isinstance(res, dict) else None
        if not video_id and isinstance(res, dict):
            video_id = res.get("id")

        if video_id:
            safe_vid = html.escape(str(video_id))
            send_message(chat_id, f"📡 Відео передано до Meta (ID: <code>{safe_vid}</code>). Очікуємо фіналізації...")
            try:
                poll_reel_status(video_id)
            except Exception as poll_err:
                print(f"⚠️ Попередження під час опитування статусу Reel: {poll_err}", file=sys.stderr)

            live_url = f"https://www.facebook.com/reel/{video_id}"
            success_text = (
                f"🎉 <b>Відео успішно опубліковано у Facebook Reels!</b>\n\n"
                f"🎬 <b>Назва:</b> {html.escape(title)}\n"
                f"🆔 <b>Video ID:</b> <code>{safe_vid}</code>\n"
                f"🔗 <b>Дивитися на Facebook:</b> {live_url}"
            )
            send_message(chat_id, success_text)
        else:
            send_message(
                chat_id,
                f"🎉 <b>Reel успішно опубліковано!</b>\n\n"
                f"🔗 <b>Сторінка:</b> https://www.facebook.com/{PAGE_ID}"
            )
    except Exception as e:
        clean_err = sanitize_text(str(e))
        send_message(chat_id, f"❌ Помилка під час публікації Reel «{html.escape(title)}»:\n<code>{html.escape(clean_err)}</code>")
    finally:
        # Clean up video file and queue state
        try:
            if video_path.exists():
                video_path.unlink(missing_ok=True)
        except Exception:
            pass
        REELS_QUEUE.pop(item_uuid, None)
        save_reels_queue(REELS_QUEUE)
        cleanup_reels_queue_dir()


def handle_stats(chat_id: int) -> None:
    """Fetch and display Facebook Page statistics and comments replies."""
    followers = "N/A"
    fans = "N/A"
    if PAGE_ID and PAGE_TOKEN:
        try:
            url = f"https://graph.facebook.com/v19.0/{PAGE_ID}?fields=name,followers_count,fan_count&access_token={PAGE_TOKEN}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                followers = data.get("followers_count", "N/A")
                fans = data.get("fan_count", "N/A")
        except Exception:
            pass

    replies_count = load_comment_replies_count()
    active_reels = len(REELS_QUEUE)

    stats_msg = (
        f"📊 <b>Статистика Facebook Automation Suite:</b>\n\n"
        f"📄 <b>Сторінка:</b> {html.escape(PAGE_NAME)} (ID: <code>{html.escape(str(PAGE_ID))}</code>)\n"
        f"👥 <b>Підписники:</b> {html.escape(str(followers))}\n"
        f"👍 <b>Лайки (fan_count):</b> {html.escape(str(fans))}\n"
        f"💬 <b>Оброблених коментарів з відповіддю:</b> {replies_count}\n"
        f"📹 <b>Активних Reels у черзі бота:</b> {active_reels}"
    )
    send_message(chat_id, stats_msg)


def handle_post_command(chat_id: int, topic: str) -> None:
    """Handle /post <тема> command to publish on-demand post."""
    post_topic = topic or "Event-Driven vs Outbox Pattern: надійність без розподілених блокувань"
    send_message(chat_id, f"⏳ Генеруємо та публікуємо пост на тему: «<b>{html.escape(post_topic)}</b>»...")
    try:
        res = fb_autopost.run_slot(0, topic=post_topic, dry_run=False)
        post_id = res.get("post_id") or "N/A"
        safe_post_id = html.escape(str(post_id))
        safe_topic = html.escape(str(res.get('topic') or post_topic))
        send_message(
            chat_id,
            f"🎉 <b>Успішно опубліковано пост у Facebook!</b>\n\n"
            f"🎯 <b>Тема:</b> {safe_topic}\n"
            f"🆔 <b>Post ID:</b> <code>{safe_post_id}</code>\n"
            f"🔗 <b>Сторінка:</b> https://www.facebook.com/{PAGE_ID}"
        )
    except Exception as e:
        clean_err = sanitize_text(str(e))
        send_message(chat_id, f"❌ Помилка публікації посту:\n<code>{html.escape(clean_err)}</code>")


def enqueue_video(
    video_path: Union[str, Path],
    title: Optional[str] = None,
    description: Optional[str] = None,
    chat_id: Optional[Union[int, str]] = None
) -> str:
    """Enqueue video into REELS_QUEUE, persist to disk, and send preview message with inline keyboard."""
    v_path = Path(video_path).resolve()
    if not v_path.exists():
        raise FileNotFoundError(f"Video file not found: {v_path}")

    cid = int(chat_id or ADMIN_CHAT_ID)
    v_url = fb_utils.find_url(description)
    if v_url and (not title or is_generic_filename(title)):
        meta = fb_utils.fetch_url_metadata(v_url)
        user_note = description.replace(v_url, "").strip() if description else ""
        v_title, v_desc = fb_utils.format_reel_from_url(v_url, meta, user_note=user_note)
    else:
        v_title = title or clean_filename_to_title(v_path.name, caption=description)
        v_desc = description or generate_reel_description(v_title)

    item_uuid = uuid.uuid4().hex[:12]
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    dest_path = QUEUE_DIR / f"{item_uuid}.mp4"

    if v_path != dest_path:
        if str(v_path).startswith(str(QUEUE_DIR)) or str(v_path).startswith("/tmp"):
            shutil.move(v_path, dest_path)
        else:
            shutil.copyfile(v_path, dest_path)

    file_size = dest_path.stat().st_size
    file_size_mb = file_size / (1024 * 1024)

    item = {
        "uuid": item_uuid,
        "path": dest_path,
        "title": v_title,
        "description": v_desc,
        "url": v_url,
        "chat_id": cid,
        "file_size_mb": file_size_mb,
        "publishing": False,
        "created_at": time.time()
    }
    REELS_QUEUE[item_uuid] = item
    save_reels_queue(REELS_QUEUE)

    preview_msg = (
        f"🎬 <b>Новий Reel готовий до публікації!</b>\n\n"
        f"📌 <b>Назва:</b> {html.escape(v_title)}\n"
        f"📁 <b>Розмір:</b> {file_size_mb:.2f} MB\n\n"
        f"📝 <b>Опис:</b>\n{html.escape(v_desc)}\n\n"
        f"Оберіть дію нижче:"
    )
    send_message(cid, preview_msg, reply_markup=build_reel_keyboard(item_uuid))
    return item_uuid


def handle_video_upload(msg: Dict[str, Any], media_obj: Dict[str, Any]) -> None:
    """Handle incoming .mp4 video upload from admin."""
    chat_id = msg["chat"]["id"]
    file_id = media_obj["file_id"]
    raw_name = media_obj.get("file_name") or "Reel_Video.mp4"
    caption = (msg.get("caption") or "").strip()
    file_size = media_obj.get("file_size") or 0

    found_url = fb_utils.find_url(caption)
    pending_state = USER_STATES.get(chat_id)
    pending_url = pending_state.get("pending_url") if (isinstance(pending_state, dict) and "pending_url" in pending_state) else None

    if found_url:
        send_message(chat_id, "🤖 <i>Аналізую посилання та адаптую назву для Reel через AI...</i>")
        meta = fb_utils.fetch_url_metadata(found_url)
        user_note = caption.replace(found_url, "").strip()
        title, desc = fb_utils.format_reel_from_url(found_url, meta, user_note=user_note)
    elif pending_url:
        send_message(chat_id, "🤖 <i>Аналізую посилання та адаптую назву для Reel через AI...</i>")
        meta = pending_state.get("meta") or fb_utils.fetch_url_metadata(pending_url)
        user_note = caption.strip() or pending_state.get("note", "")
        title, desc = fb_utils.format_reel_from_url(pending_url, meta, user_note=user_note)
        USER_STATES.pop(chat_id, None)
    else:
        title = clean_filename_to_title(raw_name, caption=caption)
        desc = caption if caption else generate_reel_description(title)

    # Telegram Public Cloud Bot API 20MB limit defense
    is_public_api = TELEGRAM_API_URL.startswith("https://api.telegram.org")
    if is_public_api and file_size > 20 * 1024 * 1024:
        file_size_mb = file_size / (1024 * 1024)
        warn_msg = (
            f"⚠️ <b>Файл завеликий для стандартного Telegram Bot API</b>\n\n"
            f"📁 <b>Файл:</b> «{html.escape(raw_name)}»\n"
            f"📊 <b>Розмір:</b> <b>{file_size_mb:.2f} MB</b> (ліміт хмарного Bot API: 20 MB).\n\n"
            f"💡 <b>Як опублікувати:</b>\n"
            f"1️⃣ <b>Швидке завантаження через fb_upload.py з Mac (миттєво):</b>\n"
            f"   <code>./bin/fb_upload.py \"/шлях/до/{html.escape(raw_name)}\"</code>\n\n"
            f"2️⃣ <b>Або пряме завантаження файлів до 2 GB через Telegram:</b>\n"
            f"   Запустіть локальний сервер Telegram Bot API на VPS (потрібні <code>api_id</code> та <code>api_hash</code> з https://my.telegram.org)."
        )
        send_message(chat_id, warn_msg)
        return

    item_uuid = uuid.uuid4().hex[:12]
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    dest_path = QUEUE_DIR / f"{item_uuid}.mp4"

    send_message(chat_id, f"📥 Завантажуємо відео «<b>{html.escape(title)}</b>» на сервер...")
    try:
        download_telegram_file(file_id, dest_path)
    except Exception as e:
        clean_err = sanitize_text(str(e))
        send_message(chat_id, f"❌ Помилка завантаження файлу: {html.escape(clean_err)}")
        return

    actual_size = dest_path.stat().st_size if dest_path.exists() else file_size
    actual_size_mb = actual_size / (1024 * 1024)
    item = {
        "uuid": item_uuid,
        "path": dest_path,
        "title": title,
        "description": desc,
        "url": found_url or pending_url,
        "chat_id": chat_id,
        "file_size_mb": actual_size_mb,
        "publishing": False,
        "created_at": time.time()
    }
    REELS_QUEUE[item_uuid] = item
    save_reels_queue(REELS_QUEUE)

    preview_msg = (
        f"🎬 <b>Новий Reel готовий до публікації!</b>\n\n"
        f"📌 <b>Назва:</b> {html.escape(title)}\n"
        f"📁 <b>Розмір:</b> {actual_size_mb:.2f} MB\n\n"
        f"📝 <b>Опис:</b>\n{html.escape(desc)}\n\n"
        f"Оберіть дію нижче:"
    )
    send_message(chat_id, preview_msg, reply_markup=build_reel_keyboard(item_uuid))


def handle_callback(cb: Dict[str, Any]) -> None:
    """Handle interactive inline keyboard callbacks."""
    cb_id = cb["id"]
    data = cb.get("data", "")
    chat_id = cb.get("from", {}).get("id")
    msg = cb.get("message")
    msg_id = msg.get("message_id") if msg else None

    if ":" not in data:
        answer_callback_query(cb_id, text="Невідома дія")
        return

    action, item_uuid = data.split(":", 1)

    if action == "publish":
        item = REELS_QUEUE.get(item_uuid)
        if not item:
            REELS_QUEUE.update(load_reels_queue())
            item = REELS_QUEUE.get(item_uuid)

        if not item:
            answer_callback_query(cb_id, text="❌ Відео не знайдено в черзі", show_alert=True)
            return

        if item.get("publishing"):
            answer_callback_query(cb_id, text="⏳ Публікація вже триває...", show_alert=True)
            return

        item["publishing"] = True
        save_reels_queue(REELS_QUEUE)
        answer_callback_query(cb_id, text="🚀 Публікацію розпочато...")

        # Disable/update message to prevent duplicate clicks
        if msg_id:
            try:
                edit_message_text(
                    chat_id,
                    msg_id,
                    f"🎬 <b>{html.escape(item['title'])}</b>\n\n⏳ <i>Публікація в процесі... Зачекайте завершення.</i>"
                )
            except Exception:
                pass

        # Dispatch background thread for async publishing
        threading.Thread(
            target=execute_publish,
            args=(item_uuid, chat_id, msg_id),
            daemon=True
        ).start()

    elif action == "title":
        item = REELS_QUEUE.get(item_uuid)
        if not item:
            REELS_QUEUE.update(load_reels_queue())
            item = REELS_QUEUE.get(item_uuid)

        if item and item.get("publishing"):
            answer_callback_query(cb_id, text="⚠️ Відео вже публікується, зміна назви недоступна", show_alert=True)
            return

        answer_callback_query(cb_id, text="🏷️ Очікую нову назву...")
        USER_STATES[chat_id] = {"action": "edit_title", "uuid": item_uuid}
        send_message(chat_id, "🏷️ Надішліть нову назву для цього Reel текстовим повідомленням:")

    elif action == "edit":
        item = REELS_QUEUE.get(item_uuid)
        if not item:
            REELS_QUEUE.update(load_reels_queue())
            item = REELS_QUEUE.get(item_uuid)

        if item and item.get("publishing"):
            answer_callback_query(cb_id, text="⚠️ Відео вже публікується, зміна опису недоступна", show_alert=True)
            return

        answer_callback_query(cb_id, text="✏️ Очікую новий опис...")
        USER_STATES[chat_id] = {"action": "edit_description", "uuid": item_uuid}
    elif action == "regen":
        item = REELS_QUEUE.get(item_uuid)
        if not item:
            REELS_QUEUE.update(load_reels_queue())
            item = REELS_QUEUE.get(item_uuid)

        if not item:
            answer_callback_query(cb_id, text="❌ Відео не знайдено в черзі", show_alert=True)
            return

        if item.get("publishing"):
            answer_callback_query(cb_id, text="⚠️ Відео вже публікується, зміна недоступна", show_alert=True)
            return

        answer_callback_query(cb_id, text="🪄 Перегенеровую назву та опис через AI...")
        source_url = item.get("url") or fb_utils.find_url(item.get("description"))
        meta = {"title": item.get("title", ""), "description": item.get("description", "")}
        if source_url:
            new_title, new_desc = fb_utils.format_reel_from_url(source_url, meta)
        else:
            new_title = fb_utils.edit_reel_title(item.get("title", ""), raw_description=item.get("description"))
            new_desc = generate_reel_description(new_title)

        item["title"] = new_title
        item["description"] = new_desc
        save_reels_queue(REELS_QUEUE)

        updated_msg = (
            f"🎬 <b>Новий Reel готовий до публікації! (Оновлено через AI)</b>\n\n"
            f"📌 <b>Назва:</b> {html.escape(item['title'])}\n"
            f"📁 <b>Розмір:</b> {item.get('file_size_mb', 0):.2f} MB\n\n"
            f"📝 <b>Опис:</b>\n{html.escape(item['description'])}\n\n"
            f"Оберіть дію нижче:"
        )
        if msg_id:
            try:
                edit_message_text(chat_id, msg_id, updated_msg, reply_markup=build_reel_keyboard(item_uuid))
            except Exception:
                send_message(chat_id, updated_msg, reply_markup=build_reel_keyboard(item_uuid))
        else:
            send_message(chat_id, updated_msg, reply_markup=build_reel_keyboard(item_uuid))

    elif action == "cancel":
        item = REELS_QUEUE.get(item_uuid)
        if not item:
            REELS_QUEUE.update(load_reels_queue())
            item = REELS_QUEUE.get(item_uuid)

        if item and item.get("publishing"):
            answer_callback_query(cb_id, text="⚠️ Неможливо скасувати: публікація вже в процесі!", show_alert=True)
            return

        item = REELS_QUEUE.pop(item_uuid, None)
        save_reels_queue(REELS_QUEUE)
        if item and item.get("path") and Path(item["path"]).exists():
            try:
                Path(item["path"]).unlink(missing_ok=True)
            except Exception:
                pass
        cleanup_reels_queue_dir()
        answer_callback_query(cb_id, text="❌ Скасовано")
        cancel_text = "❌ Публікацію скасовано, відео видалено з черги."
        if msg_id:
            edit_message_text(chat_id, msg_id, cancel_text)
        else:
            send_message(chat_id, cancel_text)


def handle_cancel_command(chat_id: int) -> None:
    """Clear any active USER_STATES and send confirmation."""
    had_state = bool(USER_STATES.pop(chat_id, None))
    if had_state:
        send_message(chat_id, "❌ Поточну дію скасовано. Стан очищено.")
    else:
        send_message(chat_id, "ℹ️ Немає активних дій для скасування.")


def handle_message(msg: Dict[str, Any]) -> None:
    """Handle incoming text or media message."""
    chat_id = msg["chat"]["id"]
    text = (msg.get("text") or "").strip()

    # Priority check: /cancel command clears active user state immediately
    if text.lower() == "/cancel" or text.lower().startswith("/cancel "):
        handle_cancel_command(chat_id)
        return

    # Check pending state for editing title
    if USER_STATES.get(chat_id, {}).get("action") == "edit_title":
        item_uuid = USER_STATES[chat_id]["uuid"]
        if item_uuid not in REELS_QUEUE:
            REELS_QUEUE.update(load_reels_queue())

        if item_uuid in REELS_QUEUE:
            found_url = fb_utils.find_url(text)
            if found_url:
                meta = fb_utils.fetch_url_metadata(found_url)
                user_note = text.replace(found_url, "").strip()
                new_title, new_desc = fb_utils.format_reel_from_url(found_url, meta, user_note=user_note)
                REELS_QUEUE[item_uuid]["title"] = new_title
                REELS_QUEUE[item_uuid]["description"] = new_desc
            else:
                old_title = REELS_QUEUE[item_uuid]["title"]
                new_title = text.strip()
                REELS_QUEUE[item_uuid]["title"] = new_title

                current_desc = REELS_QUEUE[item_uuid].get("description", "")
                if old_title and old_title in current_desc:
                    REELS_QUEUE[item_uuid]["description"] = current_desc.replace(old_title, new_title, 1)
                elif not current_desc or current_desc.startswith("🚀 "):
                    REELS_QUEUE[item_uuid]["description"] = generate_reel_description(new_title)

            save_reels_queue(REELS_QUEUE)

            updated_msg = (
                f"✅ <b>Назву успішно оновлено!</b>\n\n"
                f"🎬 <b>Нова назва:</b> {html.escape(REELS_QUEUE[item_uuid]['title'])}\n\n"
                f"📝 <b>Опис:</b>\n{html.escape(REELS_QUEUE[item_uuid]['description'])}\n\n"
                f"Оберіть дію нижче:"
            )
            send_message(
                chat_id,
                updated_msg,
                reply_markup=build_reel_keyboard(item_uuid)
            )
        else:
            send_message(chat_id, "❌ Відео вже не знайдено в черзі.")
        del USER_STATES[chat_id]
        return

    # Check pending state for editing description
    if USER_STATES.get(chat_id, {}).get("action") == "edit_description":
        item_uuid = USER_STATES[chat_id]["uuid"]
        if item_uuid not in REELS_QUEUE:
            REELS_QUEUE.update(load_reels_queue())

        if item_uuid in REELS_QUEUE:
            found_url = fb_utils.find_url(text)
            if found_url:
                meta = fb_utils.fetch_url_metadata(found_url)
                user_note = text.replace(found_url, "").strip()
                url_title, new_desc = fb_utils.format_reel_from_url(found_url, meta, user_note=user_note)
                REELS_QUEUE[item_uuid]["description"] = new_desc
                if meta.get("title") and is_generic_filename(REELS_QUEUE[item_uuid]["title"]):
                    REELS_QUEUE[item_uuid]["title"] = url_title
            else:
                REELS_QUEUE[item_uuid]["description"] = text

            save_reels_queue(REELS_QUEUE)
            updated_msg = (
                f"✅ <b>Опис успішно оновлено!</b>\n\n"
                f"🎬 <b>Назва:</b> {html.escape(REELS_QUEUE[item_uuid]['title'])}\n\n"
                f"📝 <b>Новий опис:</b>\n{html.escape(REELS_QUEUE[item_uuid]['description'])}\n\n"
                f"Оберіть дію нижче:"
            )
            send_message(
                chat_id,
                updated_msg,
                reply_markup=build_reel_keyboard(item_uuid)
            )
        else:
            send_message(chat_id, "❌ Відео вже не знайдено в черзі.")
        del USER_STATES[chat_id]
        return

    # Check commands
    if text.startswith("/"):
        parts = text.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if cmd in ["/start", "/help"]:
            welcome = (
                f"👋 Привіт, Василю! Бот автоматизації Facebook Page готовий до роботи.\n\n"
                f"📄 <b>Сторінка:</b> «{html.escape(PAGE_NAME)}» (ID: <code>{html.escape(str(PAGE_ID))}</code>)\n\n"
                f"<b>Доступні можливості:</b>\n"
                f"📹 <b>Надішліть .mp4 відео</b> — бот завантажить його та сформує чергу для публікації Reels з прев'ю та кнопками.\n"
                f"🔗 <b>Надішліть посилання (URL)</b> — бот автоматично підтягне назву та опис для поточного або наступного Reel.\n"
                f"📝 <b>/post &lt;тема&gt;</b> — згенерувати та опублікувати експертний лонгрід у Facebook.\n"
                f"📊 <b>/stats</b> — переглянути актуальну статистику сторінки та коментарів.\n"
                f"❌ <b>/cancel</b> — скасувати поточну дію та скинути активний стан."
            )
            send_message(chat_id, welcome)
            return

        elif cmd == "/cancel":
            handle_cancel_command(chat_id)
            return

        elif cmd == "/stats":
            handle_stats(chat_id)
            return

        elif cmd == "/post":
            handle_post_command(chat_id, arg)
            return

        else:
            send_message(chat_id, f"❓ Невідома команда <code>{html.escape(cmd)}</code>. Доступні: /start, /post, /stats, /cancel")
            return

    # Check video or document upload (.mp4)
    video = msg.get("video")
    doc = msg.get("document")

    is_mp4_doc = False
    if doc:
        mime = doc.get("mime_type", "")
        fname = (doc.get("file_name") or "").lower()
        if mime == "video/mp4" or fname.endswith(".mp4"):
            is_mp4_doc = True

    if video or is_mp4_doc:
        handle_video_upload(msg, video or doc)
        return

    # Check if text contains a URL
    found_url = fb_utils.find_url(text)
    if found_url:
        send_message(chat_id, "🤖 <i>Аналізую посилання та адаптую назву для Reel через AI...</i>")
        meta = fb_utils.fetch_url_metadata(found_url)
        user_note = text.replace(found_url, "").strip()
        url_title, url_desc = fb_utils.format_reel_from_url(found_url, meta, user_note=user_note)

        # Look for any existing active Reel in queue that is not publishing
        active_reels = [
            item for item in REELS_QUEUE.values()
            if item.get("chat_id") == chat_id and not item.get("publishing")
        ]
        if active_reels:
            target_item = sorted(active_reels, key=lambda x: x.get("created_at", 0), reverse=True)[0]
            item_uuid = target_item["uuid"]
            target_item["title"] = url_title
            target_item["description"] = url_desc
            target_item["url"] = found_url
            save_reels_queue(REELS_QUEUE)

            updated_msg = (
                f"🔗 <b>Оновлено назву та опис за посиланням!</b>\n\n"
                f"📌 <b>Назва:</b> {html.escape(url_title)}\n\n"
                f"📝 <b>Опис:</b>\n{html.escape(url_desc)}\n\n"
                f"Оберіть дію нижче:"
            )
            send_message(chat_id, updated_msg, reply_markup=build_reel_keyboard(item_uuid))
            return
        else:
            USER_STATES[chat_id] = {
                "pending_url": found_url,
                "meta": meta,
                "note": user_note
            }
            display_title = meta.get("title") or found_url
            info_msg = (
                f"🔗 <b>Отримано посилання для майбутнього Reel:</b>\n"
                f"«<b>{html.escape(display_title)}</b>»\n\n"
                f"📹 Тепер надішліть .mp4 відео — бот автоматично застосує цю назву та опис до відео."
            )
            send_message(chat_id, info_msg)
            return

    if text:
        send_message(
            chat_id,
            "ℹ️ Надішліть .mp4 відео або посилання для Reels, або скористайтеся командами (/post <тема>, /stats)."
        )


def handle_update(update: Dict[str, Any]) -> None:
    """Route Telegram update to appropriate handler after strict authorization check."""
    chat_id: Optional[int] = None
    if "message" in update:
        chat_id = update["message"].get("chat", {}).get("id")
    elif "callback_query" in update:
        chat_id = update["callback_query"].get("from", {}).get("id")

    if not is_authorized(chat_id):
        if chat_id:
            send_message(
                chat_id,
                "⛔ Доступ заборонено. Цей бот призначений виключно для авторизованого адміністратора."
            )
        return

    if "callback_query" in update:
        handle_callback(update["callback_query"])
    elif "message" in update:
        handle_message(update["message"])


def signal_handler(sig: int, frame: Any) -> None:
    """Handle termination signals for graceful shutdown."""
    global RUNNING
    print(f"\n🛑 Отримано сигнал {sig}. Завершуємо роботу Telegram daemon...")
    RUNNING = False


def run_daemon(poll_timeout: int = 25) -> None:
    """Start Telegram bot daemon with long-polling loop."""
    global RUNNING
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print("=" * 65)
    print(f"🤖 Запуск Telegram Bot Daemon — @AutoFaceB_bot")
    print(f"🔑 Admin Chat ID: {ADMIN_CHAT_ID}")
    print(f"📄 Facebook Page: {PAGE_NAME} (ID: {PAGE_ID})")
    print(f"📁 Черга Reels: {QUEUE_DIR}")
    print("=" * 65)

    offset = 0
    while RUNNING:
        try:
            updates_res = telegram_api_request(
                "getUpdates",
                params={
                    "offset": offset,
                    "timeout": poll_timeout,
                    "allowed_updates": ["message", "callback_query"]
                },
                timeout=poll_timeout + 10
            )

            if not updates_res.get("ok"):
                print(f"⚠️ getUpdates повернув помилку: {updates_res}", file=sys.stderr)
                time.sleep(2)
                continue

            for update in updates_res.get("result", []):
                update_id = update.get("update_id", 0)
                offset = max(offset, update_id + 1)
                try:
                    handle_update(update)
                except Exception as update_err:
                    clean_err = sanitize_text(str(update_err))
                    print(f"❌ Помилка обробки update #{update_id}: {clean_err}", file=sys.stderr)

        except Exception as err:
            if not RUNNING:
                break
            clean_err = sanitize_text(str(err))
            print(f"⚠️ Помилка long-polling циклу: {clean_err}", file=sys.stderr)
            time.sleep(3)

    print("🏁 Telegram daemon зупинено коректно.")


def main():
    parser = argparse.ArgumentParser(
        description="Interactive Telegram Bot Daemon (@AutoFaceB_bot) — Vasyl Tech Lead"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=25,
        help="Час очікування long-polling getUpdates у секундах (default: 25)"
    )
    parser.add_argument(
        "--enqueue",
        type=str,
        help="Шлях до локального .mp4 відео для постановки в чергу публікації Reels"
    )
    parser.add_argument(
        "--title",
        type=str,
        default="",
        help="Кастомна назва для Reels (використовується з --enqueue)"
    )
    parser.add_argument(
        "--caption",
        type=str,
        default="",
        help="Кастомний опис для Reels (використовується з --enqueue)"
    )
    args = parser.parse_args()

    if args.enqueue:
        uuid_val = enqueue_video(
            video_path=args.enqueue,
            title=args.title or None,
            description=args.caption or None,
            chat_id=ADMIN_CHAT_ID
        )
        print(f"✓ Відео успішно додано до черги Reels (UUID: {uuid_val})")
        sys.exit(0)

    run_daemon(poll_timeout=args.timeout)


if __name__ == "__main__":
    main()

