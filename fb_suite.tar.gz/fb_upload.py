#!/usr/bin/env python3
"""
VasylAI Facebook Reels Uploader (CLI Tool)
Uploads videos directly to VPS 2 or local queue, bypassing Telegram's 20MB bot download limit,
and triggers the interactive Telegram approval flow (@AutoFaceB_bot).
"""

import os
import sys
import uuid
import socket
import argparse
import subprocess
from pathlib import Path
from typing import Optional

# Ensure bin directory is in sys.path
_BIN_DIR = Path(__file__).resolve().parent
if str(_BIN_DIR) not in sys.path:
    sys.path.insert(0, str(_BIN_DIR))

try:
    import fb_utils
    from fb_utils import load_env, mask_token, sanitize_text
    import fb_bot
except ImportError:
    import bin.fb_utils as fb_utils
    from bin.fb_utils import load_env, mask_token, sanitize_text
    from bin import fb_bot

load_env()

VPS_USER = os.environ.get("FB_VPS_USER", "ubuntu")
VPS_HOST = os.environ.get("FB_VPS_HOST", "158.180.29.226")


def is_running_on_vps() -> bool:
    """Check if the script is currently executing directly on VPS 2."""
    try:
        hostname = socket.gethostname()
        if "threads-auto" in hostname or Path("/home/ubuntu/.local/bin/fb_bot.py").exists():
            return True
    except Exception:
        pass
    return False


def upload_reel(
    file_path: str,
    title: Optional[str] = None,
    caption: Optional[str] = None,
    url: Optional[str] = None,
    vps_host: Optional[str] = None,
    vps_user: Optional[str] = None
) -> str:
    """Upload video to Reels queue (either locally or via SCP to VPS 2)."""
    p = Path(file_path).resolve()
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"Файл не знайдено: {p}")

    valid_exts = {".mp4", ".mov", ".mkv", ".avi", ".m4v", ".webm"}
    if p.suffix.lower() not in valid_exts:
        raise ValueError(f"Непідтримуваний формат файлу: {p.suffix}. Очікується .mp4 або .mov")

    file_size_bytes = p.stat().st_size
    file_size_mb = file_size_bytes / (1024 * 1024)

    target_url = url or fb_utils.find_url(caption)
    if target_url:
        meta = fb_utils.fetch_url_metadata(target_url)
        user_note = caption.replace(target_url, "").strip() if caption else ""
        url_title, url_desc = fb_utils.format_reel_from_url(target_url, meta, user_note=user_note)
        reel_title = title or url_title
        reel_caption = caption if (caption and target_url not in caption) else url_desc
    else:
        reel_caption = caption
        if not title:
            if fb_bot.is_generic_filename(p.name) and not caption:
                if sys.stdin and sys.stdin.isatty():
                    try:
                        user_input = input(f"🏷️ Відео має технічну назву «{p.name}». Введіть назву для Reel (Enter для авто): ").strip()
                        reel_title = user_input or fb_bot.clean_filename_to_title(p.name, caption=caption)
                    except Exception:
                        reel_title = fb_bot.clean_filename_to_title(p.name, caption=caption)
                else:
                    reel_title = fb_bot.clean_filename_to_title(p.name, caption=caption)
            else:
                reel_title = fb_bot.clean_filename_to_title(p.name, caption=caption)
        else:
            reel_title = title

    print("=" * 65)
    print("📤 VasylAI Facebook Reels Direct Uploader")
    print(f"📁 Файл: {p.name} ({file_size_mb:.2f} MB)")
    print(f"🎯 Назва: «{reel_title}»")
    if target_url:
        print(f"🔗 URL: {target_url}")
    print("=" * 65)

    # 1. Local execution on VPS
    if is_running_on_vps():
        print("[1/1] 🤖 Додавання відео до локальної черги Telegram бота...")
        item_uuid = fb_bot.enqueue_video(
            video_path=p,
            title=reel_title,
            description=reel_caption,
            chat_id=fb_bot.ADMIN_CHAT_ID
        )
        print(f"✓ Відео успішно зареєстровано в черзі бота (UUID: {item_uuid})!")
        return item_uuid

    # 2. Remote execution from Mac/local machine
    host = vps_host or VPS_HOST
    user = vps_user or VPS_USER
    remote_uuid = uuid.uuid4().hex[:12]
    remote_dest = f"/tmp/fb_reels_queue/{remote_uuid}.mp4"

    print(f"[1/2] 📡 Передача відео на сервер VPS 2 ({user}@{host})...")
    # Ensure remote directory exists
    mkdir_cmd = [
        "ssh", "-o", "ConnectTimeout=10", "-o", "StrictHostKeyChecking=no",
        f"{user}@{host}", "mkdir -p /tmp/fb_reels_queue"
    ]
    subprocess.run(mkdir_cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    # SCP video file
    scp_cmd = [
        "scp", "-o", "ConnectTimeout=30", "-o", "StrictHostKeyChecking=no",
        str(p), f"{user}@{host}:{remote_dest}"
    ]
    res_scp = subprocess.run(scp_cmd, capture_output=True, text=True)
    if res_scp.returncode != 0:
        raise RuntimeError(f"Помилка передачі файлу через SCP: {res_scp.stderr}")

    print("✓ Відео успішно завантажено на сервер VPS 2!")

    print("[2/2] 🤖 Реєстрація у черзі Telegram бота @AutoFaceB_bot...")
    # Safe remote command invocation
    # Format python invocation on remote
    remote_py_cmd = (
        f"/usr/bin/python3 /home/ubuntu/.local/bin/fb_bot.py "
        f"--enqueue '{remote_dest}' "
        f"--title {subprocess.list2cmdline([reel_title])} "
    )
    if reel_caption:
        remote_py_cmd += f"--caption {subprocess.list2cmdline([reel_caption])} "

    ssh_enqueue_cmd = [
        "ssh", "-o", "ConnectTimeout=15", "-o", "StrictHostKeyChecking=no",
        f"{user}@{host}", remote_py_cmd
    ]
    res_ssh = subprocess.run(ssh_enqueue_cmd, capture_output=True, text=True)
    if res_ssh.returncode != 0:
        raise RuntimeError(f"Помилка постановки в чергу на VPS: {res_ssh.stderr}")

    print("✓ Зареєстровано в черзі бота!")
    print("=" * 65)
    print("🎉 УСПІХ! Відео передано до черги Reels.")
    print("📲 Відкрийте бота в Telegram (@AutoFaceB_bot) та натисніть:")
    print("   [ 🚀 Опублікувати Reel ]")
    print("=" * 65)
    return remote_uuid


def main():
    parser = argparse.ArgumentParser(
        description="VasylAI Facebook Reels Uploader — Direct Video Upload to VPS & Bot"
    )
    parser.add_argument(
        "file",
        type=str,
        help="Шлях до відеофайлу (.mp4)"
    )
    parser.add_argument(
        "--title",
        type=str,
        default="",
        help="Кастомна назва для Reel"
    )
    parser.add_argument(
        "--caption",
        type=str,
        default="",
        help="Кастомний опис для Reel (якщо не вказано — генерується автоматично)"
    )
    parser.add_argument(
        "--url",
        type=str,
        default="",
        help="Посилання (URL) на статтю/джерело для автоматичного вилучення назви та опису"
    )
    parser.add_argument(
        "--host",
        type=str,
        default="",
        help=f"IP/хост VPS (default: {VPS_HOST})"
    )
    parser.add_argument(
        "--user",
        type=str,
        default="",
        help=f"Користувач VPS (default: {VPS_USER})"
    )

    args = parser.parse_args()

    try:
        upload_reel(
            file_path=args.file,
            title=args.title or None,
            caption=args.caption or None,
            url=args.url or None,
            vps_host=args.host or None,
            vps_user=args.user or None
        )
    except Exception as e:
        print(f"❌ Помилка: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
