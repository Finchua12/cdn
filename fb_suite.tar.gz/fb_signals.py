#!/usr/bin/env python3
"""
VasylAI Live Signal Scraper & Formatter
Fetches fresh Open-Source projects and live AI news (strictly <= 48 hours)
and formats them for Facebook / Threads following Zero Link Penalty standards.
"""

import os
import sys
import json
import re
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional

try:
    from fb_utils import sanitize_text, load_env
except ImportError:
    from bin.fb_utils import sanitize_text, load_env

load_env()

def contains_cjk(text: Optional[str]) -> bool:
    """
    Check if string contains Chinese, Japanese, or Korean characters / hieroglyphs.
    Covers CJK Unified Ideographs, Hiragana, Katakana, Hangul, and CJK Extension blocks.
    """
    if not text:
        return False
    return bool(re.search(r'[\u4e00-\u9fff\u3400-\u4dbf\u3040-\u30ff\uac00-\ud7af]', text))

AI_KEYWORD_REGEX = re.compile(
    r'(?:\b(ai|шi|llm|gpt|gemini|claude|deepseek|vllm|copilot|копілот|frontier\s+model|neural|embedding|rag)\b|штучн\w*\s+інтелект\w*|нейромереж\w*|машинн\w*\s+навчанн\w*)',
    re.IGNORECASE
)

# Curated high-value open-source repositories with >= 5,000 stars and stellar engineering appeal
CURATED_OPENSOURCE_FALLBACKS: List[Dict[str, Any]] = [
    {
        "name": "crawl4ai",
        "full_name": "unclecode/crawl4ai",
        "url": "https://github.com/unclecode/crawl4ai",
        "description": "Легковажний, оптимізований під LLM веб-краулер і парсер контенту без блокувань.",
        "stars": 34200,
        "language": "Python",
        "points": [
            "Очищає сторінки від реклами, скриптів та стилів, віддаючи структурований Markdown для RAG-пайплайнів.",
            "Працює швидше за звичайні браузерні автоматизації завдяки пулу асинхронних контекстів.",
            "Вбудовані евристики для вилучення ключового тексту статей без використання дорогих API парсингу."
        ],
        "question": "💬 Який краулер використовуєте для RAG: локальні бібліотеки чи підписку на сторонній SaaS?"
    },
    {
        "name": "browser-use",
        "full_name": "browser-use/browser-use",
        "url": "https://github.com/browser-use/browser-use",
        "description": "Автономний агент для керування веб-браузером через мовні моделі з візуальним сприйняттям.",
        "stars": 29400,
        "language": "Python",
        "points": [
            "Поєднує скріншоти сторінки та DOM-дерево для надійного клікання та заповнення складних форм.",
            "Вирішує реальну проблему автоматизації сайтів, які не мають публічних REST або GraphQL API.",
            "Підтримує інтеграцію з локальними vision-моделями для повної конфіденційності даних."
        ],
        "question": "💬 Чи довіряєте ви AI-агентам виконувати реальні дії в браузері від вашого імені?"
    },
    {
        "name": "sqlglot",
        "full_name": "tobymao/sqlglot",
        "url": "https://github.com/tobymao/sqlglot",
        "description": "Безкомпромісний SQL-парсер, транслятор та оптимізатор для 20+ діалектів баз даних.",
        "stars": 7800,
        "language": "Python",
        "points": [
            "Транслює запити між Postgres, Snowflake, BigQuery та DuckDB без втрати семантики.",
            "Дозволяє перевіряти синтаксис та безпеку SQL-запитів перед відправкою до бази даних.",
            "Незамінний інструмент для валідації запитів, згенерованих AI-агентами."
        ],
        "question": "💬 Чи перевіряєте ви SQL від AI детермінованими парсерами перед виконанням на проді?"
    },
    {
        "name": "vllm",
        "full_name": "vllm-project/vllm",
        "url": "https://github.com/vllm-project/vllm",
        "description": "Високопродуктивний рушій для інференсу та сервінгу LLM з алгоритмом PagedAttention.",
        "stars": 38500,
        "language": "Python / C++",
        "points": [
            "PagedAttention практично до нуля знижує фрагментацію KV-кешу в памʼяті GPU.",
            "Підтримка безперервного батчінгу запитів збільшує throughput у 2-4 рази порівняно зі стандартними бекендами.",
            "Нативна підтримка квантування FP8, AWQ та GPTQ для економії серверного бюджету."
        ],
        "question": "💬 Що крутите на власному залізі: vLLM, Ollama чи TGI від HuggingFace?"
    },
    {
        "name": "uv",
        "full_name": "astral-sh/uv",
        "url": "https://github.com/astral-sh/uv",
        "description": "Надшвидкий пакетний менеджер та резолвер залежностей для Python, написаний на Rust.",
        "stars": 49000,
        "language": "Rust",
        "points": [
            "Встановлює пакети у 10-100 разів швидше за традиційний pip завдяки глобальному кешу і паралелізму.",
            "Повністю замінює pip-tools, virtualenv та poetry в єдиному швидкісному бінарнику.",
            "Детерміновані lock-файли гарантують стабільність білдів у CI/CD пайплайнах."
        ],
        "question": "💬 Встигли вже перевести робочі CI/CD пайплайни на uv чи поки лишаєтеся на pip/poetry?"
    }
]

# Evergreen AI System Architecture Fallbacks (No fake release versions, strictly engineering principles)
CURATED_AI_NEWS_FALLBACKS: List[Dict[str, Any]] = [
    {
        "title": "Prompt Caching в агентних системах: як зекономити до 80% бюджету на повторному контексті",
        "url": "https://news.ycombinator.com",
        "summary": "Архітектура префіксного кешування системних інструкцій та RAG-контексту в сучасних LLM-пайплайнах.",
        "source": "AI Architecture",
        "points": [
            "Зниження вартості токенів до 80% на повторюваних системних промптах завдяки детермінованому вирівнюванню памʼяті KV-кешу.",
            "Зменшення затримки Time to First Token (TTFT) у 3-5 разів у сценаріях багатокрокових автономних агентів.",
            "Архітектурний компроміс: необхідність суворої стандартизації структури запитів для збереження високого Cache Hit Ratio."
        ],
        "question": "💬 Чи використовуєте ви промпт-кешування у своїх агентах і скільки бюджету це реально економить?"
    },
    {
        "title": "Hybrid Search у RAG: поєднання Dense Vector пошуку та Sparse BM25",
        "url": "https://news.ycombinator.com",
        "summary": "Чому чистий векторний пошук програє гібридному підходу на специфічних технічних термінах та кодових базах.",
        "source": "RAG Engineering",
        "points": [
            "Dense ембеддинги чудово розуміють абстрактний зміст, але часто провалюються на точних назвах функцій, стек-трейсах або артикулах.",
            "Reciprocal Rank Fusion (RRF) дозволяє ефективно поєднувати результати векторного та текстового пошуку без ручного підбору ваг.",
            "Вбудовані рішення типу pgvector з повнотекстовим індексом PostgreSQL усувають потребу в окремих важких кластерах."
        ],
        "question": "💬 Який підхід до RAG показав найкращу точність у вашому проєкті: чистий векторний чи гібридний?"
    },
    {
        "title": "Structured Outputs у продакшені: перехід від ретраїв до граматично керованого семплінгу",
        "url": "https://news.ycombinator.com",
        "summary": "Як constrain decoding (CFG / JSON Schema) гарантує 100% валідний JSON без збоїв парсингу.",
        "source": "LLM Production",
        "points": [
            "Формування маски допустимих токенів на кожному кроці генерації гарантує детерміноване дотримання контракту даних.",
            "Усунення помилок парсингу на рівні логіки інференсу знижує кількість повторних запитів до нуля.",
            "Зниження навантаження на бекенд та скорочення затримки відповіді в агентних пайплайнах."
        ],
        "question": "💬 Чи використовуєте ви жорсткий JSON Schema enforcement чи парсите відповіді через retry-обгортки?"
    },
    {
        "title": "Local vs Cloud Inference: аналіз TCO при розгортанні власних моделей",
        "url": "https://news.ycombinator.com",
        "summary": "Порівняння вартості та продуктивності використання хмарних API проти власного заліза з vLLM.",
        "source": "AI Infra",
        "points": [
            "При стабільному навантаженні від 500k токенів на хвилину власний GPU-кластер стає значно вигіднішим за підписку на API.",
            "FP8 та AWQ квантування дозволяють запустити моделі з 70B параметрів на доступних серверах без відчутної втрати якості коду.",
            "Головний виклик: обслуговування інфраструктури, моніторинг vLLM/TRT-LLM та забезпечення 99.9% uptime."
        ],
        "question": "💬 При якому обсязі навантаження ви вважаєте доцільним перехід із хмарних API на власні GPU-інференси?"
    }
]


def fetch_recent_opensource_projects(max_age_days: int = 3, min_stars: int = 5000) -> List[Dict[str, Any]]:
    """
    Fetch trending or freshly updated open-source repositories from GitHub Search API.
    Window: updated or created within max_age_days (default 3 days).
    Enforces strictly >= 5000 stars to feature only mature, trusted, high-impact projects.
    Falls back gracefully to curated >=5000 projects if network or rate limit fails.
    """
    cutoff_date = (datetime.now(timezone.utc) - timedelta(days=max_age_days)).strftime("%Y-%m-%d")
    query = f"stars:>={min_stars} pushed:>={cutoff_date}"
    encoded_q = urllib.parse.quote(query)
    url = f"https://api.github.com/search/repositories?q={encoded_q}&sort=updated&order=desc&per_page=20"

    headers = {
        "User-Agent": "VasylAI-Researcher/1.0",
        "Accept": "application/vnd.github.v3+json"
    }

    github_token = os.environ.get("GITHUB_TOKEN", "").strip()
    if github_token:
        headers["Authorization"] = f"Bearer {github_token}"

    def _execute_search(h):
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            items = data.get("items", [])
            results = []
            for item in items:
                name = item.get("name", "")
                full_name = item.get("full_name", name)
                desc = item.get("description") or "Потужний інженерний інструмент з відкритим вихідним кодом."
                stars = item.get("stargazers_count", 0)
                lang = item.get("language") or "Python"
                html_url = item.get("html_url", f"https://github.com/{full_name}")
                topics = item.get("topics", [])

                if stars < min_stars:
                    continue

                if contains_cjk(name) or contains_cjk(full_name) or contains_cjk(desc):
                    continue

                if len(desc.strip()) < 8:
                    continue

                results.append({
                    "name": name,
                    "full_name": full_name,
                    "url": html_url,
                    "description": desc.strip(),
                    "stars": stars,
                    "language": lang,
                    "topics": topics,
                    "updated_at": item.get("updated_at")
                })
            return results

    try:
        results = _execute_search(headers)
        if results:
            return results
    except urllib.error.HTTPError as e:
        if e.code == 401 and "Authorization" in headers:
            try:
                h_no_auth = {"User-Agent": "VasylAI-Researcher/1.0", "Accept": "application/vnd.github.v3+json"}
                results = _execute_search(h_no_auth)
                if results:
                    return results
            except Exception:
                pass
    except Exception:
        pass

    return [p for p in CURATED_OPENSOURCE_FALLBACKS if p.get("stars", 0) >= min_stars]


def fetch_recent_ai_news(max_age_days: int = 2) -> List[Dict[str, Any]]:
    """
    Fetch real-time, live AI announcements published within the last 48 hours.
    Sources:
    1. Ukrainian IT Media (dev.ua & DOU) with AI tags and strict word-boundary matching
    2. Google News AI RSS (Live Global Frontier AI News)
    3. HackerNews AI RSS (Community Engineering Discussions)
    Falls back to evergreen AI Architecture debates if all external networks fail.
    """
    news_items: List[Dict[str, Any]] = []
    seen_titles = set()

    # Skip clickbait/promo/events/incidents unrelated to tech releases
    skip_titles = [
        "подкаст", "podcast", "як потрапити", "квитк", "вебінар", "конференц",
        "знижк", "промокод", "вакансі", "курс", "іспит", "постражда", "атак", "офіс"
    ]

    # 1. Ukrainian tech media (dev.ua & DOU)
    ua_feeds = [
        ("dev.ua", "https://dev.ua/rss"),
        ("DOU", "https://dou.ua/feed/")
    ]
    for src, feed_url in ua_feeds:
        try:
            req = urllib.request.Request(feed_url, headers={"User-Agent": "VasylAI-Researcher/1.0"})
            with urllib.request.urlopen(req, timeout=7) as resp:
                xml_data = resp.read().decode("utf-8", errors="ignore")
            root = ET.fromstring(xml_data)
            for item in root.findall(".//item")[:20]:
                title = (item.findtext("title") or "").strip()
                link = (item.findtext("link") or "").strip()
                desc = (item.findtext("description") or "").strip()
                clean_desc = re.sub(r"<[^>]+>", "", desc).strip()
                title_clean = re.sub(r"<[^>]+>", "", title).strip()

                if contains_cjk(title_clean) or contains_cjk(clean_desc):
                    continue
                if len(title_clean) < 15 or title_clean.lower() in seen_titles:
                    continue

                if any(st in title_clean.lower() for st in skip_titles):
                    continue

                # Strict regex boundary check
                if AI_KEYWORD_REGEX.search(title_clean) or AI_KEYWORD_REGEX.search(clean_desc):
                    seen_titles.add(title_clean.lower())
                    news_items.append({
                        "title": title_clean,
                        "url": link,
                        "source": f"{src} AI",
                        "summary": clean_desc[:200] if clean_desc else title_clean,
                        "is_ukrainian": True
                    })
        except Exception:
            pass

    # 2. Google News AI (Live Global Frontier AI News < 48 hours)
    try:
        gnews_url = "https://news.google.com/rss/search?q=AI+OR+LLM+OR+OpenAI+OR+Anthropic+when:2d&hl=en-US&gl=US&ceid=US:en"
        req = urllib.request.Request(gnews_url, headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = resp.read()
        root = ET.fromstring(data)
        for item in root.findall(".//item")[:25]:
            title = (item.findtext("title") or "").strip()
            link = (item.findtext("link") or "").strip()
            parts = title.rsplit(" - ", 1)
            headline = parts[0].strip() if len(parts) > 1 else title.strip()
            src = parts[1].strip() if len(parts) > 1 else "Global AI Media"

            if contains_cjk(headline) or headline.lower() in seen_titles:
                continue
            if len(headline) < 15:
                continue

            skip_kw = ["trump", "biden", "election", "midterms", "pink slime", "stock market", "shares jump", "murder", "shooting"]
            if any(sk in headline.lower() for sk in skip_kw):
                continue

            seen_titles.add(headline.lower())
            news_items.append({
                "title": f"[{src}] {headline}",
                "url": link,
                "source": src,
                "summary": f"Свіжий технологічний реліз від {src}: {headline}",
                "is_ukrainian": False
            })
    except Exception:
        pass

    # 3. HackerNews AI RSS (Fresh developer discussions)
    try:
        hn_url = "https://hnrss.org/newest?q=AI+OR+LLM+OR+Anthropic+OR+OpenAI&points=10"
        req = urllib.request.Request(hn_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            root = ET.fromstring(resp.read())
        for item in root.findall(".//item")[:15]:
            title = (item.findtext("title") or "").strip()
            link = (item.findtext("link") or "").strip()
            if contains_cjk(title) or title.lower() in seen_titles:
                continue
            if len(title) < 15:
                continue
            seen_titles.add(title.lower())
            news_items.append({
                "title": f"[HackerNews] {title}",
                "url": link,
                "source": "HackerNews Discussion",
                "summary": f"Гаряче технічне обговорення індустрії на HackerNews: {title}",
                "is_ukrainian": False
            })
    except Exception:
        pass

    if news_items:
        return news_items

    # Seamless fallback to evergreen architectural debates (no fake version numbers)
    return list(CURATED_AI_NEWS_FALLBACKS)


def format_opensource_post(repo: Dict[str, Any]) -> Dict[str, Any]:
    """
    Format an Open-Source post strictly adhering to Ukrainian 'Василь Tech Lead' persona
    and Zero Link Penalty:
    - Post body: Hook with stars and name, 2-3 technical takeaways, dilemma question,
                 Zero-Link disclosure, exactly 1 native hashtag (#OpenSource or #DevTools).
                 NO RAW URL IN POST BODY!
    - Comment: Direct link and repo metadata for the first comment.
    """
    name = repo.get("name", "Репозиторій")
    full_name = repo.get("full_name", name)
    stars = repo.get("stars", 1000)
    lang = repo.get("language", "Python")
    url = repo.get("url", f"https://github.com/{full_name}")
    desc = repo.get("description", "Опенсорс інструмент для розробників.")

    if contains_cjk(desc) or contains_cjk(name):
        desc = "Сучасний інженерний інструмент з відкритим вихідним кодом."

    points = repo.get("points")
    if not points:
        points = [
            f"Архітектура та оптимізація: розроблено на {lang}, фокус на мінімальному споживанні ресурсів та високому throughput.",
            f"Ключова перевага: {desc[:150]}.",
            "Практична користь: дає змогу замінити дорогі пропрієтарні підписки локальним або self-hosted рішенням."
        ]

    formatted_points = "\n".join(f"• {p.lstrip('•- ')}" for p in points)
    question = repo.get("question", f"💬 Хтось уже щупав {name} на реальних задачах, чи поки тримаєтеся за звичний стек?")
    if not question.strip().endswith("?"):
        question = question.rstrip(".! ") + "?"

    hooks = [
        f"Поки всі женуться за хайпом, в опенсорсі тишком-нишком викотили серйозну штуку — {name} ({stars:,} ⭐):",
        f"Знайшов на GitHub дійсно крутий інструмент, який закриває болючу інженерну проблему — {name} ({stars:,} ⭐):",
        f"Якщо втомилися від монструозних рішень і хочете чисту продуктивність, зверніть увагу на {name} ({stars:,} ⭐):",
        f"Реліз, який вартий уваги кожного техліда та бекендера — {name} ({stars:,} ⭐):"
    ]
    hook_idx = abs(hash(name)) % len(hooks)
    hook = hooks[hook_idx]

    content = (
        f"{hook}\n\n"
        f"Стек: {lang} | {desc[:180]}\n\n"
        f"Чим чіпляє під капотом:\n"
        f"{formatted_points}\n\n"
        f"{question}\n\n"
        f"(🔗 пряме посилання на репозиторій закинув у перший коментар 👇)\n\n"
        f"#OpenSource #DevTools"
    )

    comment = f"🔗 Репозиторій: {url}\n⭐️ Зірок на GitHub: {stars:,} | Стек: {lang}"

    return {
        "content": content,
        "comment": comment,
        "topic": repo.get("topic") or f"{name}: практичний опенсорс інструмент ({stars:,} ⭐)",
        "hook": hook,
        "url": url,
        "name": name,
        "points": points,
        "question": question,
        "tags": "#OpenSource #DevTools"
    }


def format_ai_news_post(news: Dict[str, Any]) -> Dict[str, Any]:
    """
    Format an AI News post strictly adhering to Ukrainian 'Василь Tech Lead' persona
    and Zero Link Penalty:
    - Post body: Engaging hook from a real senior developer, clean architectural summary,
                 bullet points under 'Ключові інженерні висновки:', dilemma question,
                 Zero-Link disclosure, exactly 1 native hashtag (#AI).
                 NO RAW URL IN POST BODY! NO ROBOTIC TIMESTAMPS!
    - Comment: Direct source link for the first comment.
    """
    title = news.get("title", "Головні новини ШІ")
    summary = news.get("summary", "")
    url = news.get("url", "https://news.ycombinator.com")
    source = news.get("source", "AI Research")

    # If points were already provided (e.g. from evergreen fallbacks), use them
    points = news.get("points")
    question = news.get("question")

    if not points:
        t_clean = (title + " " + summary)
        # Avoid false positive "hack" inside "hackernews"
        t_for_hack = re.sub(r'hackernews', '', t_clean, flags=re.I)

        if re.search(r'\b(аватар\w*|avatar\w*|голос\w*|voice|відео\w*|video|мімік\w*)\b', t_clean, re.I):
            points = [
                "Технологічний стек: інтеграція мультимодальних моделей генерації відео та аудіо з наднизькою затримкою передачі потоку.",
                "Оптимізація ресурсів: використання легкових нейромереж для синхронізації міміки та губ на стороні клієнта.",
                "Вплив на інтерфейси: перехід від текстових чат-ботів до інтерактивних цифрових помічників у режимі реального часу."
            ]
            question = "💬 Як ставитеся до появи голосових та відео-аватарів у сервісах: корисна еволюція чи тимчасовий хайп?"
        elif re.search(r'\b(патент\w*|patent\w*|баг\w*|код\w*|вайбкодинг|ide|cursor|copilot)\b', t_clean, re.I):
            points = [
                "Інженерний підхід: використання спеціалізованих моделей для фонового сканування коду та виправлення типових регресій.",
                "Контроль якості: різниця між автономним патчингом на льоту та перевіркою детермінованими тест-сьютами.",
                "Продакшен-імпакт: автоматизація рутинного мейнтенансу дозволяє розробникам зосередитися на складній бізнес-архітектурі."
            ]
            question = "💬 Чи довірили б ви штучному інтелекту автоматичне патчення багів на живому продакшені?"
        elif re.search(r'\b(hack(?!ernews)\w*|злам\w*|безпек\w*|security|attack\w*|кібер\w*)\b', t_for_hack, re.I):
            points = [
                "Вектор загрози: автономне дослідження вразливостей та автоматичне проходження захисних барʼєрів моделями.",
                "Оцінка ризиків: необхідність ізоляції агентних систем через sandbox та суворе обмеження мережевих доступів.",
                "Практика для команд: перевірка коду, згенерованого LLM, на приховані CVE та небезпечні системні виклики."
            ]
            question = "💬 Як у ваших проєктах захищають інфраструктуру при наданні моделям доступу до зовнішніх API?"
        elif re.search(r'\b(deal|billion|\$|invest\w*|econom\w*|compute|datacenter|кластер|інфраструктур\w*)\b', t_clean, re.I):
            points = [
                "Масштаб інвестицій: розширення обчислювальних потужностей для навчання та обслуговування frontier-моделей нового покоління.",
                "Інфраструктурний виклик: боротьба за датацентри, пропускну здатність мереж та енергетичну ефективність кластерів.",
                "Прогноз для ринку: як концентрація капіталу в лідерів індустрії вплине на доступність та вартість API для звичайних розробників."
            ]
            question = "💬 Як зростання вартості інфраструктури ШІ впливає на ціноутворення та бюджети у ваших проєктах?"
        elif re.search(r'\b(frontier|pace|benchmark|research|дослідж\w*)\b', t_clean, re.I):
            points = [
                "Аналіз темпів розвитку: метрики автономності та здатність моделей вирішувати багатокрокові інженерні задачі.",
                "Економіка обчислень: співвідношення витрат на навчання великих моделей та ефективності їхнього інференсу.",
                "Прогноз для індустрії: які навички розробників стануть ключовими у найближчі роки взаємодії з frontier-системами."
            ]
            question = "💬 На які бенчмарки та метрики ви орієнтуєтеся в першу чергу при виборі моделі для власних завдань?"
        elif re.search(r'\b(смартфон\w*|chip\w*|чип\w*|ринок|market|hardware|device|qualcomm)\b', t_clean, re.I):
            points = [
                "Апаратні вимоги: дефіцит та подорожчання пам'яті через необхідність локального запуску on-device моделей.",
                "Зміна ринку: поступове витіснення бюджетних рішень на користь пристроїв з виділеними NPU-модулями.",
                "Оптимізація для мобільних: активний розвиток FP4 та int4 квантування для роботи в жорстких лімітах батареї."
            ]
            question = "💬 Чи користуєтеся локальними on-device моделями на смартфонах/ноутбуках, чи виключно хмарними API?"
        else:
            points = [
                f"Суть релізу: {summary[:150]}.",
                "Архітектурний аспект: оптимізація обчислювальних ресурсів, робота з контекстом та зниження затримок.",
                "Продакшен-імпакт: практичне застосування в сучасних агентних системах та автоматизації кодових баз."
            ]
            question = "💬 Що думаєте про цей реліз: реальний інженерний прорив чи черговий маркетинговий хайп?"

    formatted_points = "\n".join(f"• {p.lstrip('•- ')}" for p in points)
    if not question.strip().endswith("?"):
        question = question.rstrip(".! ") + "?"

    hooks = [
        f"Головний технологічний анонс дня в індустрії AI, повз який важко пройти:",
        f"Поки всі обговорюють гучні маркетингові презентації, в інженерному стеку ШІ відбуваються значно цікавіші речі:",
        f"Черговий важливий тектонічний зсув в AI-інфраструктурі, який варто розібрати по поличках:",
        f"Цікава новина для тих, хто будує продакшен на LLM, а не просто бавиться промптами:"
    ]
    hook_idx = abs(hash(title)) % len(hooks)
    hook = hooks[hook_idx]

    content = (
        f"{hook}\n\n"
        f"{title}\n\n"
        f"Ключові інженерні висновки:\n"
        f"{formatted_points}\n\n"
        f"{question}\n\n"
        f"(🔗 першоджерело та деталі залишив у першому коментарі 👇)\n\n"
        f"#AI"
    )

    comment = f"🔗 Першоджерело / анонс: {url}\nДжерело: {source}"

    return {
        "content": content,
        "comment": comment,
        "topic": news.get("topic") or title,
        "hook": hook,
        "url": url,
        "points": points,
        "question": question,
        "tags": "#AI"
    }
